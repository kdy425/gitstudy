@echo off
title iOS SSH Connector
echo.

:: =======================================================
:: SETTINGS
:: Paste your UDID below (Replace the example)
:: =======================================================
set TARGET_UDID=382de2a7f1b18124fd855d5bf26ce009aeeb4306
set LOCAL_PORT=2222
set REMOTE_PORT=22
:: =======================================================

echo [Step 1/3] Starting iproxy tunneling...
echo        Target UDID: %TARGET_UDID%
echo        Port Map   : %LOCAL_PORT% -^> %REMOTE_PORT%
echo.

:: Start iproxy in a separate PowerShell window using the variable
powershell -Command "Start-Process powershell -ArgumentList '-NoExit', '-ExecutionPolicy Bypass', '-Command', 'iproxy -u %TARGET_UDID% %LOCAL_PORT% %REMOTE_PORT%'"

echo [Step 2/3] Waiting for connection stability (3 seconds)...
timeout /t 3 >nul

echo.
echo [Step 3/3] Connecting to device via SSH...
echo -----------------------------------------------------
echo  * User: mobile (or root)
echo  * Pass: alpine (hidden when typing)
echo -----------------------------------------------------
echo.

:: Connect via SSH
ssh mobile@localhost -p %LOCAL_PORT%

echo.
echo [Info] SSH session disconnected.
echo [Info] Please close the 'iproxy' window manually.
pause
