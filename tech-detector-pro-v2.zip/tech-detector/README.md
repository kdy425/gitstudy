# Tech Detector Pro v2.0

Wappalyzer 유료 버전보다 강력한 웹 기술 탐지 및 보안 분석 Chrome 확장 프로그램.

## 주요 기능

### 🔍 기술 탐지 (200+ 기술)
- **JavaScript Frameworks**: React, Vue, Angular, Svelte, Next.js, Nuxt, Gatsby, Remix, Astro, Solid.js, Alpine.js, HTMX 등
- **CSS Frameworks**: Bootstrap, Tailwind, Material UI, Chakra UI, Ant Design, DaisyUI, Semantic UI 등
- **CMS & E-commerce**: WordPress, Drupal, Joomla, Shopify, WooCommerce, Magento, Wix, Squarespace, Webflow 등
- **서버 & 인프라**: Nginx, Apache, IIS, LiteSpeed, Caddy, Tomcat, Gunicorn 등
- **CDN**: Cloudflare, AWS CloudFront, Fastly, Akamai, KeyCDN 등
- **🛡️ WAF 탐지**: Cloudflare WAF, AWS WAF, Imperva/Incapsula, Sucuri, ModSecurity, F5 BIG-IP, Akamai WAF, FortiWeb, Barracuda, Azure Front Door, DDoS-Guard 등
- **🇰🇷 한국 플랫폼**: Cafe24, NHN Cloud, TOAST UI, Naver Analytics, Kakao SDK, XpressEngine, GNUBoard, KG이니시스, NicePay, 토스페이먼츠 등
- **Analytics**: Google Analytics, GTM, Hotjar, Mixpanel, Amplitude, Segment, Heap, Clarity, Matomo, Plausible 등
- **인증**: Auth0, Firebase Auth, Okta, Keycloak, Naver Login 등
- **고객지원**: Intercom, Zendesk, Crisp, Tawk.to, ChannelTalk, Drift 등
- **모니터링**: Sentry, LogRocket, Datadog, New Relic 등
- **결제**: Stripe, PayPal, KG이니시스, NicePay, 토스페이먼츠 등

### 🛡️ 보안 점수 시스템
- 100점 만점 보안 점수 (A+~F 등급)
- **보안 헤더 분석**: CSP, HSTS, X-Frame-Options, Referrer-Policy 등 10개 헤더 검사
- **CSP 심화 분석**: unsafe-inline, unsafe-eval, 와일드카드 사용 감지
- **HSTS 분석**: max-age, includeSubDomains, preload 검사
- **정보 노출 감지**: 서버 버전, X-Powered-By, ASP.NET 버전 노출
- **쿠키 보안**: Secure, HttpOnly, SameSite 플래그 검사
- **Mixed Content** 감지
- **SRI (Subresource Integrity)** 미적용 외부 스크립트 감지
- **인라인 이벤트 핸들러** (XSS surface) 감지

### ⚠️ CVE 취약점 분석 (Perplexity AI)
- 탐지된 기술의 버전별 알려진 CVE 확인
- CVSS 점수 표시
- 공개 익스플로잇 존재 여부
- 권장 업그레이드 버전 안내

### 📊 신뢰도 스코어링
- 각 탐지 기술에 대한 신뢰도(%) 표시
- 다중 증거 소스 기반 신뢰도 보정
- 스크립트, 헤더, HTML, 쿠키, JS 글로벌 변수 등 복합 분석

### 📁 내보내기 & 히스토리
- **JSON 내보내기**: 기술, 헤더, 보안 분석 결과 전체 포함
- **CSV 내보내기**: 스프레드시트 호환 포맷
- **스캔 히스토리**: 최근 200개 스캔 기록 자동 저장
- 호스트별 보안 등급 추적

## v1.0 → v2.0 주요 변경사항

| 기능 | v1.0 | v2.0 |
|------|------|------|
| 기술 DB | ~60개 | 200+개 |
| WAF 탐지 | ❌ | ✅ 11종+ |
| 한국 플랫폼 | ❌ | ✅ 12종+ |
| 보안 점수 | ❌ | ✅ A+~F |
| CSP 분석 | ❌ | ✅ |
| HSTS 분석 | ❌ | ✅ |
| 쿠키 보안 | ❌ | ✅ |
| 신뢰도 점수 | ❌ | ✅ |
| JSON/CSV 내보내기 | ❌ | ✅ |
| 스캔 히스토리 | ❌ | ✅ |
| 카테고리 필터 | ❌ | ✅ |
| 인라인 스크립트 분석 | ❌ | ✅ |
| 리소스 힌트 분석 | ❌ | ✅ |
| HTML 코멘트 분석 | ❌ | ✅ |
| CVSS 점수 | ❌ | ✅ |
| 익스플로잇 존재 여부 | ❌ | ✅ |

## 설치 방법

1. `chrome://extensions/` 접속
2. **개발자 모드** 활성화
3. **압축해제된 확장 프로그램을 로드합니다** 클릭
4. `tech-detector` 폴더 선택

## Perplexity API 설정

CVE 취약점 분석을 위해 Perplexity API 키가 필요합니다:

1. https://www.perplexity.ai/settings/api 에서 API 키 발급
2. 확장 프로그램 ⚙️ 설정에서 API 키 입력
3. "취약점 확인" 버튼으로 분석 실행

## 보안 연구 활용

이 도구는 모의해킹 및 보안 연구 목적으로 설계되었습니다:

- **정찰 단계**: 대상 웹사이트의 기술 스택 빠르게 파악
- **WAF 식별**: 우회 전략 수립을 위한 방화벽 종류 확인
- **취약점 매핑**: 탐지된 버전 기반 알려진 CVE 즉시 확인
- **보안 평가**: 헤더 기반 보안 설정 수준 평가
- **보고서 작성**: JSON/CSV 내보내기로 보고서 데이터 활용
