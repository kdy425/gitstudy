/**
 * Content Script v2.0 - Advanced page analysis
 * Detects technologies via DOM, scripts, meta tags, cookies, JS globals
 * Also analyzes: cookies security, CSP, robots.txt hints, sitemap
 */

(function () {
  if (window.__techDetectorRan) return;
  window.__techDetectorRan = true;

  /**
   * Collect comprehensive page data
   */
  function collectPageData() {
    const data = {
      html: "",
      scripts: [],
      inlineScripts: [],
      metas: {},
      cookies: document.cookie || "",
      cookieDetails: [],
      url: window.location.href,
      hostname: window.location.hostname,
      protocol: window.location.protocol,
      links: [],
      stylesheets: [],
      iframes: [],
      forms: [],
      inputFields: [],
      comments: [],
      resourceHints: []
    };

    // Get HTML (expanded to 200KB for better coverage)
    try {
      data.html = document.documentElement.outerHTML.substring(0, 200000);
    } catch (e) {
      data.html = "";
    }

    // Collect all script src attributes
    document.querySelectorAll("script[src]").forEach((s) => {
      const src = s.getAttribute("src") || "";
      const integrity = s.getAttribute("integrity") || "";
      const crossorigin = s.getAttribute("crossorigin") || "";
      data.scripts.push({ src, integrity, crossorigin });
    });

    // Inline script content (first 1000 chars each, up to 30 scripts)
    let inlineCount = 0;
    document.querySelectorAll("script:not([src])").forEach((s) => {
      if (s.textContent && inlineCount < 30) {
        data.inlineScripts.push(s.textContent.substring(0, 1000));
        inlineCount++;
      }
    });

    // Collect meta tags (all types)
    document.querySelectorAll("meta").forEach((m) => {
      const name = m.getAttribute("name") || m.getAttribute("property") || m.getAttribute("http-equiv") || "";
      const content = m.getAttribute("content") || "";
      if (name) {
        data.metas[name.toLowerCase()] = content;
      }
    });

    // Collect stylesheets
    document.querySelectorAll('link[rel="stylesheet"]').forEach((l) => {
      data.stylesheets.push(l.getAttribute("href") || "");
    });

    // Collect link tags
    document.querySelectorAll("link[href]").forEach((l) => {
      data.links.push({
        href: l.getAttribute("href") || "",
        rel: l.getAttribute("rel") || "",
        type: l.getAttribute("type") || ""
      });
    });

    // Resource hints (preconnect, dns-prefetch)
    document.querySelectorAll('link[rel="preconnect"], link[rel="dns-prefetch"]').forEach((l) => {
      data.resourceHints.push(l.getAttribute("href") || "");
    });

    // Collect iframes (external services detection)
    document.querySelectorAll("iframe").forEach((f) => {
      const src = f.getAttribute("src") || "";
      if (src) data.iframes.push(src.substring(0, 200));
    });

    // Collect form actions (framework detection)
    document.querySelectorAll("form").forEach((f) => {
      data.forms.push({
        action: f.getAttribute("action") || "",
        method: f.getAttribute("method") || "GET"
      });
    });

    // Input fields analysis (for security assessment)
    document.querySelectorAll("input").forEach((inp) => {
      data.inputFields.push({
        type: inp.getAttribute("type") || "text",
        name: inp.getAttribute("name") || "",
        autocomplete: inp.getAttribute("autocomplete") || ""
      });
    });

    // Extract HTML comments (often contain version info / debug info)
    const commentRegex = /<!--([\s\S]*?)-->/g;
    let commentMatch;
    let commentCount = 0;
    while ((commentMatch = commentRegex.exec(data.html)) && commentCount < 20) {
      const comment = commentMatch[1].trim().substring(0, 300);
      if (comment.length > 5) {
        data.comments.push(comment);
        commentCount++;
      }
    }

    // Parse cookie details for security analysis
    if (document.cookie) {
      document.cookie.split(";").forEach((c) => {
        const parts = c.trim().split("=");
        if (parts[0]) {
          data.cookieDetails.push({
            name: parts[0].trim(),
            valueLength: (parts[1] || "").length,
            // Note: httpOnly and secure flags aren't visible from JS
          });
        }
      });
    }

    return data;
  }

  /**
   * Check for JavaScript global variables (page context injection)
   */
  function checkJsGlobals() {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.textContent = `
        (function() {
          const globals = {};
          const checks = {
            // Frameworks
            "React": typeof React !== 'undefined',
            "React.version": typeof React !== 'undefined' ? React.version : null,
            "__REACT_DEVTOOLS_GLOBAL_HOOK__": typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined',
            "_reactRootContainer": document.getElementById('root') ? (!!document.getElementById('root')._reactRootContainer || !!Object.keys(document.getElementById('root')).find(k=>k.startsWith('__reactFiber'))) : (!!document.getElementById('app')?._reactRootContainer || false),
            "Vue": typeof Vue !== 'undefined',
            "Vue.version": typeof Vue !== 'undefined' && Vue.version ? Vue.version : null,
            "__VUE__": typeof __VUE__ !== 'undefined',
            "__VUE_DEVTOOLS_GLOBAL_HOOK__": typeof __VUE_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined',
            "angular": typeof angular !== 'undefined',
            "ng": typeof ng !== 'undefined',
            "getAllAngularRootElements": typeof getAllAngularRootElements === 'function',
            "jQuery": typeof jQuery !== 'undefined',
            "jQuery.fn.jquery": typeof jQuery !== 'undefined' ? jQuery.fn.jquery : null,
            "$": typeof $ !== 'undefined' && typeof $.fn !== 'undefined',
            "Ember": typeof Ember !== 'undefined',
            "Backbone": typeof Backbone !== 'undefined',
            "preact": typeof preact !== 'undefined',

            // CMS/E-commerce
            "Shopify": typeof Shopify !== 'undefined',
            "ShopifyAnalytics": typeof ShopifyAnalytics !== 'undefined',
            "Drupal": typeof Drupal !== 'undefined',
            "drupalSettings": typeof drupalSettings !== 'undefined',
            "wp": typeof wp !== 'undefined',
            "Mage": typeof Mage !== 'undefined',

            // Libraries
            "THREE": typeof THREE !== 'undefined',
            "d3": typeof d3 !== 'undefined',
            "Chart": typeof Chart !== 'undefined',
            "moment": typeof moment !== 'undefined',
            "io": typeof io !== 'undefined',
            "axios": typeof axios !== 'undefined',
            "gsap": typeof gsap !== 'undefined',
            "TweenMax": typeof TweenMax !== 'undefined',
            "Swiper": typeof Swiper !== 'undefined',
            "Sentry": typeof Sentry !== 'undefined',
            "__SENTRY__": typeof __SENTRY__ !== 'undefined',
            "LogRocket": typeof LogRocket !== 'undefined',

            // Build tools
            "webpackChunk": typeof webpackChunk !== 'undefined',
            "webpackJsonp": typeof webpackJsonp !== 'undefined',

            // SSR/SSG
            "__NEXT_DATA__": typeof __NEXT_DATA__ !== 'undefined',
            "__NUXT__": typeof __NUXT__ !== 'undefined',

            // Analytics
            "ga": typeof ga !== 'undefined',
            "gtag": typeof gtag !== 'undefined',
            "GoogleAnalyticsObject": typeof GoogleAnalyticsObject !== 'undefined',
            "google_tag_manager": typeof google_tag_manager !== 'undefined',
            "dataLayer": typeof dataLayer !== 'undefined' && Array.isArray(dataLayer),
            "fbq": typeof fbq !== 'undefined',
            "hj": typeof hj !== 'undefined',
            "mixpanel": typeof mixpanel !== 'undefined',
            "amplitude": typeof amplitude !== 'undefined',
            "heap": typeof heap !== 'undefined',
            "clarity": typeof clarity !== 'undefined',
            "_paq": typeof _paq !== 'undefined',
            "Matomo": typeof Matomo !== 'undefined',
            "optimizely": typeof optimizely !== 'undefined',
            "_vwo": typeof _vwo !== 'undefined',

            // Customer support
            "Intercom": typeof Intercom !== 'undefined',
            "zE": typeof zE !== 'undefined',
            "drift": typeof drift !== 'undefined',
            "$crisp": typeof $crisp !== 'undefined',
            "Tawk_API": typeof Tawk_API !== 'undefined',
            "ChannelIO": typeof ChannelIO !== 'undefined',
            "HubSpot": typeof HubSpot !== 'undefined',
            "hbspt": typeof hbspt !== 'undefined',

            // Payment
            "Stripe": typeof Stripe !== 'undefined',
            "paypal": typeof paypal !== 'undefined',

            // Korean
            "Kakao": typeof Kakao !== 'undefined',

            // Auth
            "auth0": typeof auth0 !== 'undefined',

            // Search
            "algoliasearch": typeof algoliasearch !== 'undefined',

            // State management
            "__REDUX_DEVTOOLS_EXTENSION__": typeof __REDUX_DEVTOOLS_EXTENSION__ !== 'undefined',

            // Monitoring
            "DD_RUM": typeof DD_RUM !== 'undefined',
            "newrelic": typeof newrelic !== 'undefined',
            "NREUM": typeof NREUM !== 'undefined',

            // Misc
            "grecaptcha": typeof grecaptcha !== 'undefined',
            "_": typeof _ !== 'undefined' && typeof _.VERSION !== 'undefined',
            "Lodash_version": typeof _ !== 'undefined' && _.VERSION ? _.VERSION : null
          };
          
          for (const [key, value] of Object.entries(checks)) {
            if (value !== false && value !== null && value !== undefined) {
              globals[key] = value === true ? true : value;
            }
          }
          
          // Check for service worker
          if ('serviceWorker' in navigator) {
            navigator.serviceWorker.getRegistrations().then(regs => {
              globals['__HAS_SERVICE_WORKER__'] = regs.length > 0;
            }).catch(() => {});
          }

          window.postMessage({ type: '__TECH_DETECTOR_GLOBALS__', globals: globals }, '*');
        })();
      `;

      window.addEventListener("message", function handler(event) {
        if (event.data && event.data.type === "__TECH_DETECTOR_GLOBALS__") {
          window.removeEventListener("message", handler);
          resolve(event.data.globals);
        }
      });

      setTimeout(() => resolve({}), 3000);
      (document.head || document.documentElement).appendChild(script);
      script.remove();
    });
  }

  /**
   * Analyze page security characteristics
   */
  function analyzePageSecurity() {
    const security = {
      https: window.location.protocol === "https:",
      mixedContent: false,
      passwordFieldsNoAutocompleteOff: 0,
      formsWithoutCSRF: 0,
      externalScriptsWithoutSRI: 0,
      externalScriptsTotal: 0,
      hasCSP: false,
      dangerousInlineHandlers: 0
    };

    // Check for mixed content
    document.querySelectorAll("script[src], img[src], link[href], iframe[src]").forEach((el) => {
      const src = el.getAttribute("src") || el.getAttribute("href") || "";
      if (src.startsWith("http://") && window.location.protocol === "https:") {
        security.mixedContent = true;
      }
    });

    // Check password fields
    document.querySelectorAll('input[type="password"]').forEach((inp) => {
      if (inp.getAttribute("autocomplete") !== "off" && inp.getAttribute("autocomplete") !== "new-password") {
        security.passwordFieldsNoAutocompleteOff++;
      }
    });

    // Check external scripts without SRI
    document.querySelectorAll("script[src]").forEach((s) => {
      const src = s.getAttribute("src") || "";
      if (src.startsWith("http") || src.startsWith("//")) {
        security.externalScriptsTotal++;
        if (!s.getAttribute("integrity")) {
          security.externalScriptsWithoutSRI++;
        }
      }
    });

    // Check for inline event handlers (potential XSS surface)
    const dangerousAttrs = ["onclick", "onerror", "onload", "onmouseover", "onfocus", "onblur"];
    dangerousAttrs.forEach((attr) => {
      security.dangerousInlineHandlers += document.querySelectorAll(`[${attr}]`).length;
    });

    // Check CSP meta tag
    const cspMeta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
    if (cspMeta) {
      security.hasCSP = true;
      security.cspContent = cspMeta.getAttribute("content") || "";
    }

    return security;
  }

  // Main detection flow
  async function detect() {
    const pageData = collectPageData();
    let jsGlobals = {};

    try {
      jsGlobals = await checkJsGlobals();
    } catch (e) {
      console.debug("[TechDetector] JS globals check failed:", e);
    }

    pageData.jsGlobals = jsGlobals;
    
    // Flatten scripts for backward compatibility
    pageData.scriptSrcs = pageData.scripts.map(s => typeof s === 'string' ? s : s.src);

    // Analyze page security
    pageData.pageSecurity = analyzePageSecurity();

    // Store data
    chrome.storage.local.set({
      [`pageData_${window.location.hostname}`]: {
        ...pageData,
        timestamp: Date.now()
      }
    });

    // Send to background
    chrome.runtime.sendMessage({
      type: "PAGE_DATA",
      data: pageData
    });
  }

  // Run detection
  if (document.readyState === "complete") {
    setTimeout(detect, 300);
  } else {
    window.addEventListener("load", () => {
      setTimeout(detect, 800);
    });
  }

  // Listen for requests from popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "RESCAN") {
      window.__techDetectorRan = false;
      detect().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (msg.type === "GET_PAGE_SECURITY") {
      sendResponse({ security: analyzePageSecurity() });
      return true;
    }
  });
})();
