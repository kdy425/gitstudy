/**
 * Popup Script v2.0 - Advanced UI with security scoring, export, history
 */

let currentTechnologies = [];
let currentHeaders = {};
let currentSecurityScore = null;

// ===========================
// Init
// ===========================
document.addEventListener("DOMContentLoaded", async () => {
  await loadCurrentTab();
  await loadResults();
  setupTabs();
  setupSettings();
  setupVulnCheck();
  setupRescan();
  setupExport();
  setupHistory();
});

async function loadCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    try {
      const url = new URL(tab.url);
      document.getElementById("currentUrl").textContent = url.hostname + url.pathname;
    } catch (e) {
      document.getElementById("currentUrl").textContent = tab.url || "N/A";
    }
  }
}

async function loadResults() {
  chrome.runtime.sendMessage({ type: "GET_RESULTS" }, (response) => {
    if (response) {
      currentTechnologies = response.technologies || [];
      currentHeaders = response.headers || {};
      currentSecurityScore = response.securityScore || null;
      
      renderTechnologies(currentTechnologies);
      renderHeaders(currentHeaders);
      renderSecurityScore(currentSecurityScore);
      
      document.getElementById("techCount").textContent = currentTechnologies.length;
      
      // Update category badges
      const cats = {};
      currentTechnologies.forEach(t => {
        cats[t.category] = (cats[t.category] || 0) + 1;
      });
      
      // Check for WAF
      const wafTechs = currentTechnologies.filter(t => t.category === "WAF");
      if (wafTechs.length > 0) {
        document.getElementById("wafBadge").style.display = "inline-flex";
        document.getElementById("wafBadge").textContent = "🛡️ " + wafTechs.map(w => w.name).join(", ");
      }
    }
  });
}

// ===========================
// Technology Rendering
// ===========================
function renderTechnologies(techs) {
  const container = document.getElementById("techList");
  const filterValue = document.getElementById("techFilter")?.value || "all";

  let filtered = techs;
  if (filterValue !== "all") {
    filtered = techs.filter(t => t.category === filterValue);
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="icon">🔍</div>
        <p>${techs.length === 0 ? '탐지된 기술이 없습니다' : '해당 카테고리에 탐지된 기술이 없습니다'}</p>
        <p class="sub">페이지를 새로고침한 후 다시 시도해보세요</p>
      </div>`;
    return;
  }

  // Build category filter options
  const categories = [...new Set(techs.map(t => t.category))].sort();
  const filterEl = document.getElementById("techFilter");
  if (filterEl && filterEl.children.length <= 1) {
    categories.forEach(cat => {
      const opt = document.createElement("option");
      opt.value = cat;
      opt.textContent = cat;
      filterEl.appendChild(opt);
    });
  }

  // Group by category
  const groups = {};
  filtered.forEach(t => {
    const cat = t.category || "기타";
    if (!groups[cat]) groups[cat] = [];
    groups[cat].push(t);
  });

  const categoryOrder = [
    "WAF", "Web Server", "CDN", "Caching", "Proxy",
    "JavaScript Framework", "JavaScript Library", "CSS Framework",
    "State Management", "Build Tool",
    "Web Framework", "CMS", "E-commerce", "Static Site Generator",
    "Programming Language",
    "Cloud Platform", "Cloud Storage", "PaaS", "Container",
    "Analytics", "Tag Manager", "A/B Testing", "Feature Flags",
    "Monitoring", "Error Tracking",
    "Security", "Authentication",
    "Customer Support", "CRM",
    "Payment", "Font", "API", "Search Engine", "Database",
    "Email Marketing", "Advertising", "Social", "Media",
    "Technology", "Meta"
  ];

  const sortedCategories = Object.keys(groups).sort((a, b) => {
    const ia = categoryOrder.indexOf(a);
    const ib = categoryOrder.indexOf(b);
    return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
  });

  let html = "";
  for (const cat of sortedCategories) {
    const items = groups[cat];
    html += `<div class="category-group">`;
    html += `<div class="category-label">${getCategoryIcon(cat)} ${cat} <span class="cat-count">${items.length}</span></div>`;

    for (const tech of items) {
      const confColor = tech.confidence >= 80 ? "#10b981" : tech.confidence >= 60 ? "#f59e0b" : "#ef4444";
      html += `
        <div class="tech-item" title="${(tech.evidence || []).join('\n')}">
          <div class="tech-icon">${tech.icon || '📦'}</div>
          <div class="tech-info">
            <div class="tech-name">
              ${tech.website ? `<a href="${tech.website}" target="_blank">${esc(tech.name)}</a>` : esc(tech.name)}
              ${tech.version ? `<span class="version-badge">v${esc(tech.version)}</span>` : ''}
              ${tech.implied ? `<span class="implied-badge">implied</span>` : ''}
            </div>
            <div class="tech-meta-row">
              <span class="tech-category">${tech.category}</span>
              <span class="confidence-badge" style="color:${confColor}">${tech.confidence}%</span>
            </div>
            ${tech.evidence && tech.evidence.length > 0 && !tech.implied
              ? `<div class="tech-evidence">${esc(tech.evidence[0])}</div>` : ''}
          </div>
        </div>`;
    }
    html += `</div>`;
  }

  container.innerHTML = html;
}

function getCategoryIcon(cat) {
  const icons = {
    "WAF": "🛡️", "Web Server": "🖥️", "CDN": "☁️", "JavaScript Framework": "⚡",
    "JavaScript Library": "📚", "CSS Framework": "🎨", "Web Framework": "🏗️",
    "CMS": "📝", "E-commerce": "🛍️", "Programming Language": "💻",
    "Analytics": "📊", "Security": "🔒", "Payment": "💳", "PaaS": "☁️",
    "Authentication": "🔑", "Customer Support": "💬", "Font": "🔤",
    "Build Tool": "📦", "Monitoring": "📈", "Error Tracking": "🐛",
    "Database": "🗄️", "Caching": "⚡", "Proxy": "🔀", "Container": "🐳",
    "A/B Testing": "🧪", "Tag Manager": "🏷️", "CRM": "🟠"
  };
  return icons[cat] || "📦";
}

// ===========================
// Headers Rendering
// ===========================
function renderHeaders(headers) {
  const container = document.getElementById("headerList");
  const entries = Object.entries(headers);

  if (entries.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="icon">📋</div><p>헤더 정보 없음</p></div>`;
    return;
  }

  const securityHeaders = [
    "content-security-policy", "x-content-type-options", "x-frame-options",
    "strict-transport-security", "x-xss-protection", "referrer-policy",
    "permissions-policy", "cross-origin-opener-policy", "cross-origin-embedder-policy",
    "cross-origin-resource-policy"
  ];

  const sorted = entries.sort((a, b) => {
    const aIsSec = securityHeaders.includes(a[0].toLowerCase());
    const bIsSec = securityHeaders.includes(b[0].toLowerCase());
    if (aIsSec && !bIsSec) return -1;
    if (!aIsSec && bIsSec) return 1;
    return a[0].localeCompare(b[0]);
  });

  let html = "";
  for (const [name, value] of sorted) {
    const isSecurity = securityHeaders.includes(name.toLowerCase());
    html += `
      <div class="header-item">
        <span class="header-name" style="${isSecurity ? 'color: #10b981;' : ''}">${esc(name)}</span>
        <span class="header-value">${esc(value)}</span>
      </div>`;
  }

  // Missing security headers
  const presentHeaders = entries.map(([k]) => k.toLowerCase());
  const missing = securityHeaders.filter((h) => !presentHeaders.includes(h));

  if (missing.length > 0) {
    html += `<div style="margin-top:12px"><div class="category-label" style="color:var(--warning)">⚠️ 누락된 보안 헤더 (${missing.length})</div>`;
    for (const h of missing) {
      html += `
        <div class="header-item">
          <span class="header-name" style="color:var(--danger)">${h}</span>
          <span class="header-value" style="color:var(--text-dim)">미설정</span>
        </div>`;
    }
    html += `</div>`;
  }

  container.innerHTML = html;
}

// ===========================
// Security Score Rendering
// ===========================
function renderSecurityScore(secScore) {
  const container = document.getElementById("securityScoreContent");
  if (!secScore) {
    container.innerHTML = `<div class="empty-state"><div class="icon">🛡️</div><p>보안 점수 계산 중...</p></div>`;
    return;
  }

  const { score, grade, findings } = secScore;
  const gradeColors = { "A+": "#10b981", "A": "#10b981", "B": "#3b82f6", "C": "#f59e0b", "D": "#f97316", "F": "#ef4444" };
  const gradeColor = gradeColors[grade] || "#ef4444";

  let html = `
    <div class="score-hero">
      <div class="score-circle" style="border-color:${gradeColor}">
        <div class="score-grade" style="color:${gradeColor}">${grade}</div>
        <div class="score-number">${score}/100</div>
      </div>
      <div class="score-summary">
        <div class="score-label">보안 점수</div>
        <div class="score-bar-bg"><div class="score-bar" style="width:${score}%;background:${gradeColor}"></div></div>
      </div>
    </div>`;

  if (findings.length > 0) {
    // Group by severity
    const severityOrder = ["critical", "high", "medium", "low", "info"];
    const severityLabels = { critical: "🔴 Critical", high: "🟠 High", medium: "🟡 Medium", low: "🔵 Low", info: "ℹ️ Info" };
    
    findings.sort((a, b) => severityOrder.indexOf(a.severity) - severityOrder.indexOf(b.severity));

    html += `<div class="findings-list">`;
    for (const f of findings) {
      html += `
        <div class="finding-item ${f.severity}">
          <span class="finding-severity">${severityLabels[f.severity] || f.severity}</span>
          <span class="finding-msg">${esc(f.message)}</span>
        </div>`;
    }
    html += `</div>`;
  } else {
    html += `<div class="msg-box success">✅ 주요 보안 문제가 발견되지 않았습니다.</div>`;
  }

  container.innerHTML = html;
}

// ===========================
// Tab Switching
// ===========================
function setupTabs() {
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
      document.getElementById(`tab-${tab.dataset.tab}`).classList.add("active");
    });
  });

  // Category filter
  const filterEl = document.getElementById("techFilter");
  if (filterEl) {
    filterEl.addEventListener("change", () => {
      renderTechnologies(currentTechnologies);
    });
  }
}

// ===========================
// Settings
// ===========================
function setupSettings() {
  const btnSettings = document.getElementById("btnSettings");
  const panel = document.getElementById("settingsPanel");

  chrome.runtime.sendMessage({ type: "GET_API_KEY" }, (response) => {
    if (response && response.apiKey) {
      document.getElementById("apiKeyInput").value = response.apiKey;
    }
  });

  btnSettings.addEventListener("click", () => {
    panel.classList.toggle("active");
    document.getElementById("tabBar").style.display = panel.classList.contains("active") ? "none" : "flex";
    document.querySelectorAll(".tab-content").forEach(c => {
      c.style.display = panel.classList.contains("active") ? "none" : "";
    });
    if (!panel.classList.contains("active")) {
      document.querySelectorAll(".tab-content").forEach(c => c.style.removeProperty("display"));
    }
  });

  document.getElementById("btnSaveKey").addEventListener("click", () => {
    const apiKey = document.getElementById("apiKeyInput").value.trim();
    const status = document.getElementById("saveStatus");
    if (!apiKey) { status.textContent = "❌ API 키를 입력해주세요"; status.style.color = "#ef4444"; return; }
    chrome.runtime.sendMessage({ type: "SAVE_API_KEY", apiKey }, () => {
      status.textContent = "✅ 저장됨"; status.style.color = "#10b981";
      setTimeout(() => { status.textContent = ""; }, 2000);
    });
  });
}

// ===========================
// Vulnerability Check
// ===========================
function setupVulnCheck() {
  document.getElementById("btnCheckVuln").addEventListener("click", async () => {
    const btn = document.getElementById("btnCheckVuln");
    const techsWithVersion = currentTechnologies.filter(t => t.version);

    if (techsWithVersion.length === 0) {
      document.getElementById("vulnResults").innerHTML = `
        <div class="msg-box info">ℹ️ 버전 정보가 탐지된 기술이 없습니다.</div>`;
      return;
    }

    const keyCheck = await new Promise(r => chrome.runtime.sendMessage({ type: "GET_API_KEY" }, r));
    if (!keyCheck || !keyCheck.apiKey) {
      document.getElementById("vulnResults").innerHTML = `
        <div class="msg-box error">⚠️ Perplexity API 키가 설정되지 않았습니다. ⚙️ 설정에서 입력해주세요.</div>`;
      return;
    }

    btn.disabled = true; btn.classList.add("loading"); btn.innerHTML = "🔄 Perplexity AI 분석 중...";
    document.getElementById("vulnResults").innerHTML = "";

    chrome.runtime.sendMessage({ type: "CHECK_VULNS", technologies: currentTechnologies }, (response) => {
      btn.disabled = false; btn.classList.remove("loading"); btn.innerHTML = "🛡️ 취약점 다시 확인";
      if (response.error) {
        document.getElementById("vulnResults").innerHTML = `<div class="msg-box error">❌ ${esc(response.error)}</div>`;
        return;
      }
      renderVulnResults(response.results);
    });
  });
}

function renderVulnResults(results) {
  const container = document.getElementById("vulnResults");
  if (!results || results.length === 0) {
    container.innerHTML = `<div class="msg-box info">ℹ️ 분석 결과가 없습니다.</div>`;
    return;
  }

  const counts = { critical: 0, high: 0, medium: 0, low: 0, safe: 0 };
  results.forEach(r => { const risk = (r.risk || "safe").toLowerCase(); if (counts[risk] !== undefined) counts[risk]++; });

  let html = `
    <div class="vuln-summary">
      <div class="summary-card critical"><div class="num">${counts.critical}</div><div class="label">Critical</div></div>
      <div class="summary-card high"><div class="num">${counts.high}</div><div class="label">High</div></div>
      <div class="summary-card medium"><div class="num">${counts.medium}</div><div class="label">Medium</div></div>
      <div class="summary-card safe"><div class="num">${counts.safe + counts.low}</div><div class="label">Safe</div></div>
    </div>`;

  const riskOrder = ["critical", "high", "medium", "low", "safe"];
  results.sort((a, b) => riskOrder.indexOf((a.risk || "safe").toLowerCase()) - riskOrder.indexOf((b.risk || "safe").toLowerCase()));

  for (const vuln of results) {
    const risk = (vuln.risk || "safe").toLowerCase();
    html += `
      <div class="vuln-item ${risk}">
        <div class="vuln-header">
          <span class="vuln-tech-name">${esc(vuln.name)} ${esc(vuln.version || '')}</span>
          <span class="risk-badge ${risk}">${vuln.risk || 'SAFE'}</span>
        </div>
        <div class="vuln-detail">
          ${vuln.summary ? `<p>${esc(vuln.summary)}</p>` : ''}
          ${vuln.latest_version ? `<p style="margin-top:4px"><span class="label">권장 버전: </span><span style="color:var(--success)">${esc(vuln.latest_version)}</span></p>` : ''}
          ${vuln.exploit_available ? `<p style="margin-top:2px;color:var(--danger)">⚠️ 공개 익스플로잇 존재</p>` : ''}
          ${vuln.cves && vuln.cves.length > 0 ? `
            <div style="margin-top:6px"><span class="label">CVE</span>
              <div class="cve-list">
                ${vuln.cves.map((cve, i) => `
                  <a class="cve-tag ${risk === 'safe' ? 'safe' : ''}" 
                     href="https://nvd.nist.gov/vuln/detail/${encodeURIComponent(cve)}" 
                     target="_blank">${esc(cve)}${vuln.cvss_scores && vuln.cvss_scores[i] ? ` (${vuln.cvss_scores[i]})` : ''}</a>
                `).join('')}
              </div>
            </div>` : `<div style="margin-top:4px"><span class="cve-tag safe">알려진 CVE 없음</span></div>`}
        </div>
      </div>`;
  }

  container.innerHTML = html;
}

// ===========================
// Rescan
// ===========================
function setupRescan() {
  document.getElementById("btnRescan").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "RESCAN_PAGE" }, () => {
      setTimeout(loadResults, 1500);
    });
    document.getElementById("techList").innerHTML = `<div class="empty-state"><div class="icon">🔄</div><p>다시 스캔 중...</p></div>`;
  });
}

// ===========================
// Export
// ===========================
function setupExport() {
  document.getElementById("btnExportJSON")?.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "EXPORT_JSON" }, (response) => {
      if (response && response.data) downloadFile(response.data, "tech-detector-report.json", "application/json");
    });
  });

  document.getElementById("btnExportCSV")?.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "EXPORT_CSV" }, (response) => {
      if (response && response.data) downloadFile(response.data, "tech-detector-report.csv", "text/csv");
    });
  });
}

function downloadFile(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ===========================
// History
// ===========================
function setupHistory() {
  document.getElementById("btnShowHistory")?.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "GET_HISTORY" }, (response) => {
      renderHistory(response.history || []);
    });
  });

  document.getElementById("btnClearHistory")?.addEventListener("click", () => {
    if (confirm("스캔 히스토리를 모두 삭제하시겠습니까?")) {
      chrome.runtime.sendMessage({ type: "CLEAR_HISTORY" }, () => {
        document.getElementById("historyContent").innerHTML = `<div class="msg-box success">✅ 히스토리가 삭제되었습니다.</div>`;
      });
    }
  });
}

function renderHistory(history) {
  const container = document.getElementById("historyContent");
  if (history.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="icon">📜</div><p>스캔 히스토리가 없습니다</p></div>`;
    return;
  }

  let html = `<div class="history-count">${history.length}개 스캔 기록</div>`;
  for (const item of history.slice(0, 50)) {
    const date = new Date(item.timestamp);
    const dateStr = `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;
    const gradeColor = { "A+": "#10b981", "A": "#10b981", "B": "#3b82f6", "C": "#f59e0b", "D": "#f97316", "F": "#ef4444" };

    html += `
      <div class="history-item">
        <div class="history-main">
          <span class="history-host">${esc(item.hostname)}</span>
          <span class="history-date">${dateStr}</span>
        </div>
        <div class="history-meta">
          <span class="history-tech-count">${item.techCount} techs</span>
          <span class="history-grade" style="color:${gradeColor[item.securityGrade] || '#999'}">${item.securityGrade}</span>
        </div>
      </div>`;
  }

  container.innerHTML = html;
}

// ===========================
// Utilities
// ===========================
function esc(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
