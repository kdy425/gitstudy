/**
 * Technology Fingerprint Database v2.0
 * 200+ technologies with confidence scoring
 * 
 * Each entry can have:
 * - scripts: regex patterns to match against <script src="">
 * - meta: { name: regex } to match <meta> tags
 * - headers: { headerName: regex } to match HTTP response headers
 * - html: regex patterns to match against page HTML
 * - cookies: regex patterns to match cookie names
 * - js: { globalVar: regex } to check window object properties
 * - implies: array of other technologies implied by this one
 * - excludes: array of technologies that cannot coexist
 * - category: technology category
 * - website: official website
 * - icon: emoji icon for display
 * - confidence: default confidence level (1-100)
 * - cpe: CPE identifier for CVE matching
 */

const FINGERPRINTS = {
  // ===========================
  // JavaScript Frameworks
  // ===========================
  "React": {
    category: "JavaScript Framework",
    icon: "⚛️",
    website: "https://reactjs.org",
    cpe: "cpe:/a:facebook:react",
    scripts: [/react(?:\.min)?\.js/i, /react-dom(?:\.min)?\.js/i, /react\.production\.min\.js/i],
    html: [/data-reactroot/i, /data-reactid/i, /__NEXT_DATA__/, /data-react-helmet/i],
    js: { "React": null, "__REACT_DEVTOOLS_GLOBAL_HOOK__": null, "_reactRootContainer": null },
    versionPatterns: { js: { "React.version": null } },
    confidence: 90
  },

  "Next.js": {
    category: "JavaScript Framework",
    icon: "▲",
    website: "https://nextjs.org",
    cpe: "cpe:/a:vercel:next.js",
    scripts: [/_next\/static/i, /_next\/data/i, /_next\/image/i],
    html: [/__NEXT_DATA__/, /_next\/static/, /__next/i, /next-route-announcer/i],
    meta: { "generator": /Next\.js\s*([\d.]+)?/i },
    headers: { "x-powered-by": /Next\.js/i, "x-nextjs-cache": /.*/i },
    implies: ["React", "Node.js", "Webpack"],
    versionPatterns: { meta: { "generator": /Next\.js\s*([\d.]+)/i }, html: [/__NEXT_DATA__.*"buildId"/] },
    confidence: 95
  },

  "Vue.js": {
    category: "JavaScript Framework",
    icon: "💚",
    website: "https://vuejs.org",
    cpe: "cpe:/a:vuejs:vue",
    scripts: [/vue(?:\.min|\.global|\.runtime)?\.js/i, /vue@[\d]/i, /vue\.global\.prod/i],
    html: [/data-v-[a-f0-9]+/i, /v-cloak/i, /\sv-bind:/i, /\sv-on:/i, /\sv-if/i, /\sv-for/i],
    js: { "Vue": null, "__VUE__": null, "__VUE_DEVTOOLS_GLOBAL_HOOK__": null },
    versionPatterns: { js: { "Vue.version": null } },
    confidence: 90
  },

  "Nuxt.js": {
    category: "JavaScript Framework",
    icon: "💚",
    website: "https://nuxtjs.org",
    cpe: "cpe:/a:nuxtjs:nuxt",
    scripts: [/_nuxt\//i],
    html: [/__NUXT__/, /_nuxt\//, /nuxt-link/i, /data-n-head/i],
    headers: { "x-powered-by": /Nuxt/i },
    implies: ["Vue.js", "Node.js"],
    versionPatterns: { meta: { "generator": /Nuxt\s*([\d.]+)/i } },
    confidence: 95
  },

  "Angular": {
    category: "JavaScript Framework",
    icon: "🅰️",
    website: "https://angular.io",
    cpe: "cpe:/a:google:angular",
    scripts: [/angular(?:\.min)?\.js/i, /@angular\/core/i, /zone\.js/i],
    html: [/ng-version="([\d.]+)"/i, /ng-app/i, /\[ng-/i, /ng-controller/i, /_nghost-/i, /_ngcontent-/i, /ng-star-inserted/i],
    js: { "angular": null, "ng": null, "getAllAngularRootElements": null },
    versionPatterns: { html: [/ng-version="([\d.]+)"/i] },
    confidence: 90
  },

  "jQuery": {
    category: "JavaScript Library",
    icon: "📘",
    website: "https://jquery.com",
    cpe: "cpe:/a:jquery:jquery",
    scripts: [/jquery[.-]?([\d.]+)?(?:\.min)?\.js/i, /jquery\.slim/i, /jquery-migrate/i],
    js: { "jQuery": null, "jQuery.fn.jquery": null },
    versionPatterns: { scripts: [/jquery[.-]([\d.]+)/i], js: { "jQuery.fn.jquery": null } },
    confidence: 85
  },

  "Svelte": {
    category: "JavaScript Framework",
    icon: "🔥",
    website: "https://svelte.dev",
    html: [/svelte-[a-z0-9]+/i, /class="svelte-/i, /class="s-[A-Za-z0-9]/i],
    scripts: [/svelte/i, /__sveltekit/i],
    confidence: 85
  },

  "SvelteKit": {
    category: "JavaScript Framework",
    icon: "🔥",
    website: "https://kit.svelte.dev",
    html: [/__sveltekit/i, /data-sveltekit/i],
    scripts: [/__sveltekit/i],
    implies: ["Svelte"],
    confidence: 90
  },

  "Ember.js": {
    category: "JavaScript Framework",
    icon: "🐹",
    website: "https://emberjs.com",
    scripts: [/ember(?:\.min)?\.js/i],
    html: [/ember-view/i, /data-ember/i, /class="ember-/i],
    js: { "Ember": null, "Em": null },
    confidence: 85
  },

  "Backbone.js": {
    category: "JavaScript Library",
    icon: "🦴",
    website: "https://backbonejs.org",
    scripts: [/backbone(?:\.min)?\.js/i],
    js: { "Backbone": null },
    implies: ["Underscore.js"],
    confidence: 80
  },

  "Underscore.js": {
    category: "JavaScript Library",
    icon: "📚",
    website: "https://underscorejs.org",
    scripts: [/underscore(?:\.min)?\.js/i],
    js: { "_": null },
    confidence: 70
  },

  "Alpine.js": {
    category: "JavaScript Framework",
    icon: "🏔️",
    website: "https://alpinejs.dev",
    scripts: [/alpine(?:\.min)?\.js/i, /cdn\..*alpine/i],
    html: [/x-data\s*=/i, /x-bind:/i, /x-on:/i, /x-show/i, /x-transition/i, /@click/i],
    confidence: 80
  },

  "HTMX": {
    category: "JavaScript Library",
    icon: "📡",
    website: "https://htmx.org",
    scripts: [/htmx(?:\.min)?\.js/i],
    html: [/hx-get/i, /hx-post/i, /hx-trigger/i, /hx-swap/i, /hx-target/i],
    confidence: 85
  },

  "Remix": {
    category: "JavaScript Framework",
    icon: "💿",
    website: "https://remix.run",
    html: [/__remix/i, /remix-run/i],
    scripts: [/remix/i],
    implies: ["React", "Node.js"],
    confidence: 80
  },

  "Gatsby": {
    category: "JavaScript Framework",
    icon: "🟣",
    website: "https://www.gatsbyjs.com",
    meta: { "generator": /Gatsby\s*([\d.]+)?/i },
    html: [/gatsby-/i, /___gatsby/i, /gatsby-image/i],
    implies: ["React", "Webpack", "GraphQL"],
    versionPatterns: { meta: { "generator": /Gatsby\s*([\d.]+)/i } },
    confidence: 90
  },

  "Preact": {
    category: "JavaScript Framework",
    icon: "⚛️",
    website: "https://preactjs.com",
    scripts: [/preact(?:\.min)?\.js/i],
    js: { "preact": null },
    confidence: 80
  },

  "Solid.js": {
    category: "JavaScript Framework",
    icon: "🔷",
    website: "https://www.solidjs.com",
    scripts: [/solid-js/i],
    html: [/data-hk/i],
    confidence: 75
  },

  "Stimulus": {
    category: "JavaScript Framework",
    icon: "⚡",
    website: "https://stimulus.hotwired.dev",
    html: [/data-controller/i, /data-action/i, /data-target/i],
    scripts: [/stimulus/i, /hotwired/i],
    confidence: 75
  },

  "Turbo": {
    category: "JavaScript Library",
    icon: "⚡",
    website: "https://turbo.hotwired.dev",
    html: [/data-turbo/i, /turbo-frame/i, /turbo-stream/i],
    scripts: [/turbo/i, /hotwired/i],
    confidence: 75
  },

  "Lit": {
    category: "JavaScript Framework",
    icon: "🔥",
    website: "https://lit.dev",
    scripts: [/lit-element/i, /lit-html/i, /@lit\//i],
    confidence: 75
  },

  "Polymer": {
    category: "JavaScript Framework",
    icon: "🔴",
    website: "https://polymer-library.polymer-project.org",
    html: [/polymer/i, /iron-/i, /paper-/i],
    scripts: [/polymer/i, /webcomponents/i],
    confidence: 75
  },

  "Astro": {
    category: "JavaScript Framework",
    icon: "🚀",
    website: "https://astro.build",
    meta: { "generator": /Astro\s*([\d.]+)?/i },
    html: [/astro-/i, /data-astro/i],
    versionPatterns: { meta: { "generator": /Astro\s*v?([\d.]+)/i } },
    confidence: 90
  },

  // ===========================
  // CSS Frameworks
  // ===========================
  "Bootstrap": {
    category: "CSS Framework",
    icon: "🅱️",
    website: "https://getbootstrap.com",
    cpe: "cpe:/a:getbootstrap:bootstrap",
    scripts: [/bootstrap(?:\.bundle)?(?:\.min)?\.js/i],
    html: [/class="[^"]*\b(?:container-fluid|col-(?:xs|sm|md|lg|xl)-\d|navbar-toggler|btn-primary|btn-secondary)\b/i],
    versionPatterns: { scripts: [/bootstrap[.-]?([\d.]+)/i] },
    confidence: 80
  },

  "Tailwind CSS": {
    category: "CSS Framework",
    icon: "🌊",
    website: "https://tailwindcss.com",
    html: [
      /class="[^"]*(?:flex|grid|hidden)\s[^"]*(?:sm:|md:|lg:|xl:|2xl:)/i,
      /class="[^"]*(?:bg-(?:white|black|gray|red|blue|green|yellow|indigo|purple|pink)|text-(?:sm|base|lg|xl|2xl)|p-\d|m-\d|rounded-)/i
    ],
    scripts: [/tailwind/i],
    confidence: 70
  },

  "Bulma": {
    category: "CSS Framework",
    icon: "🟢",
    website: "https://bulma.io",
    html: [/class="[^"]*\b(?:is-primary|is-info|is-success|is-warning|is-danger|column is-|hero is-|notification)\b/i],
    scripts: [/bulma/i],
    confidence: 75
  },

  "Material UI": {
    category: "CSS Framework",
    icon: "🎨",
    website: "https://mui.com",
    html: [/class="[^"]*Mui[A-Z]/i, /class="[^"]*MuiButton/i, /class="[^"]*css-[a-z0-9]+-Mui/i],
    scripts: [/@mui\/material/i, /material-ui/i],
    implies: ["React"],
    confidence: 80
  },

  "Chakra UI": {
    category: "CSS Framework",
    icon: "⚡",
    website: "https://chakra-ui.com",
    html: [/class="[^"]*chakra-/i, /data-theme/i],
    scripts: [/chakra-ui/i, /@chakra-ui/i],
    implies: ["React"],
    confidence: 75
  },

  "Ant Design": {
    category: "CSS Framework",
    icon: "🐜",
    website: "https://ant.design",
    html: [/class="[^"]*ant-/i, /class="[^"]*antd/i],
    scripts: [/antd/i, /ant-design/i],
    implies: ["React"],
    confidence: 80
  },

  "Foundation": {
    category: "CSS Framework",
    icon: "🏗️",
    website: "https://get.foundation",
    html: [/class="[^"]*(?:small-\d|medium-\d|large-\d|reveal-modal|orbit)\b/i],
    scripts: [/foundation(?:\.min)?\.js/i],
    confidence: 75
  },

  "Semantic UI": {
    category: "CSS Framework",
    icon: "📐",
    website: "https://semantic-ui.com",
    html: [/class="[^"]*ui\s(?:button|container|segment|grid|header|form|menu|modal)\b/i],
    scripts: [/semantic(?:\.min)?\.js/i],
    confidence: 75
  },

  "DaisyUI": {
    category: "CSS Framework",
    icon: "🌼",
    website: "https://daisyui.com",
    html: [/class="[^"]*(?:btn-|card-|badge-|alert-|modal-|drawer-|navbar)\b[^"]*(?:btn-primary|btn-ghost|card-body)/i, /data-theme="[^"]+"/i],
    implies: ["Tailwind CSS"],
    confidence: 70
  },

  "Materialize": {
    category: "CSS Framework",
    icon: "🎨",
    website: "https://materializecss.com",
    html: [/class="[^"]*(?:materialize|waves-effect|sidenav|card-panel|z-depth)\b/i],
    scripts: [/materialize(?:\.min)?\.js/i],
    confidence: 75
  },

  // ===========================
  // CMS & E-commerce
  // ===========================
  "WordPress": {
    category: "CMS",
    icon: "📝",
    website: "https://wordpress.org",
    cpe: "cpe:/a:wordpress:wordpress",
    meta: { "generator": /WordPress\s*([\d.]+)?/i },
    html: [/wp-content\/plugins/i, /wp-content\/themes/i, /wp-includes/i, /wp-json/i, /wp-emoji-release/i],
    headers: { "x-powered-by": /WordPress/i, "link": /wp-json/i },
    cookies: [/wordpress_/i, /wp-settings/i],
    versionPatterns: { meta: { "generator": /WordPress\s*([\d.]+)/i } },
    confidence: 95
  },

  "Drupal": {
    category: "CMS",
    icon: "💧",
    website: "https://www.drupal.org",
    cpe: "cpe:/a:drupal:drupal",
    meta: { "generator": /Drupal\s*([\d.]+)?/i },
    html: [/\/sites\/default\/files/i, /Drupal\.settings/i, /drupal\.js/i, /\/core\/misc\/drupal\.js/i],
    headers: { "x-drupal-cache": /.*/i, "x-generator": /Drupal/i, "x-drupal-dynamic-cache": /.*/i },
    js: { "Drupal": null, "drupalSettings": null },
    confidence: 90
  },

  "Joomla": {
    category: "CMS",
    icon: "🔴",
    website: "https://www.joomla.org",
    cpe: "cpe:/a:joomla:joomla",
    meta: { "generator": /Joomla/i },
    html: [/\/media\/jui\/js/i, /\/components\/com_/i, /Joomla\.optionsStorage/i],
    headers: { "x-content-encoded-by": /Joomla/i },
    confidence: 90
  },

  "Shopify": {
    category: "E-commerce",
    icon: "🛍️",
    website: "https://www.shopify.com",
    html: [/cdn\.shopify\.com/i, /Shopify\.theme/i, /shopify-section/i, /myshopify\.com/i],
    js: { "Shopify": null, "ShopifyAnalytics": null },
    headers: { "x-shopify-stage": /.*/i, "x-shopid": /.*/i },
    cookies: [/_shopify_/i],
    confidence: 95
  },

  "WooCommerce": {
    category: "E-commerce",
    icon: "🛒",
    website: "https://woocommerce.com",
    cpe: "cpe:/a:woocommerce:woocommerce",
    html: [/woocommerce/i, /wc-block/i, /is-type-product/i],
    scripts: [/woocommerce/i],
    implies: ["WordPress", "PHP"],
    confidence: 85
  },

  "Magento": {
    category: "E-commerce",
    icon: "🧡",
    website: "https://magento.com",
    cpe: "cpe:/a:magento:magento",
    html: [/\/static\/version/i, /mage\/cookies/i, /Magento_/i, /requirejs-config\.js/i],
    cookies: [/PHPSESSID/i, /mage-/i, /form_key/i],
    headers: { "x-magento-vary": /.*/i },
    js: { "Mage": null },
    implies: ["PHP"],
    confidence: 85
  },

  "PrestaShop": {
    category: "E-commerce",
    icon: "🛒",
    website: "https://www.prestashop.com",
    cpe: "cpe:/a:prestashop:prestashop",
    meta: { "generator": /PrestaShop/i },
    html: [/prestashop/i, /\/modules\/ps_/i],
    cookies: [/PrestaShop/i],
    implies: ["PHP"],
    confidence: 85
  },

  "BigCommerce": {
    category: "E-commerce",
    icon: "🏪",
    website: "https://www.bigcommerce.com",
    html: [/bigcommerce/i, /cdn11\.bigcommerce\.com/i],
    headers: { "x-bc-": /.*/i },
    confidence: 80
  },

  "Wix": {
    category: "CMS",
    icon: "🌐",
    website: "https://www.wix.com",
    html: [/wix\.com/i, /X-Wix/i, /_wixCIDX/i, /wix-dropdown/i],
    meta: { "generator": /Wix/i },
    scripts: [/static\.parastorage\.com/i, /static\.wixstatic\.com/i],
    confidence: 90
  },

  "Squarespace": {
    category: "CMS",
    icon: "⬛",
    website: "https://www.squarespace.com",
    html: [/squarespace/i, /static\.squarespace\.com/i, /sqs-/i],
    meta: { "generator": /Squarespace/i },
    confidence: 90
  },

  "Ghost": {
    category: "CMS",
    icon: "👻",
    website: "https://ghost.org",
    meta: { "generator": /Ghost\s*([\d.]+)?/i },
    html: [/ghost-(?:url|api)/i, /\/ghost\/api/i],
    headers: { "x-ghost-cache-status": /.*/i },
    versionPatterns: { meta: { "generator": /Ghost\s*([\d.]+)/i } },
    confidence: 90
  },

  "Hugo": {
    category: "Static Site Generator",
    icon: "📄",
    website: "https://gohugo.io",
    meta: { "generator": /Hugo\s*([\d.]+)?/i },
    html: [/hugo-/i],
    versionPatterns: { meta: { "generator": /Hugo\s*([\d.]+)/i } },
    confidence: 85
  },

  "Jekyll": {
    category: "Static Site Generator",
    icon: "📄",
    website: "https://jekyllrb.com",
    meta: { "generator": /Jekyll\s*([\d.]+)?/i },
    html: [/jekyll/i],
    confidence: 80
  },

  "Webflow": {
    category: "CMS",
    icon: "🔵",
    website: "https://webflow.com",
    meta: { "generator": /Webflow/i },
    html: [/webflow/i, /wf-/i],
    scripts: [/webflow\.js/i],
    confidence: 90
  },

  "Strapi": {
    category: "CMS",
    icon: "🚀",
    website: "https://strapi.io",
    headers: { "x-powered-by": /Strapi/i },
    implies: ["Node.js"],
    confidence: 80
  },

  "Contentful": {
    category: "CMS",
    icon: "📦",
    website: "https://www.contentful.com",
    html: [/contentful/i, /ctfassets\.net/i],
    scripts: [/contentful/i],
    confidence: 75
  },

  // ===========================
  // Korean Platforms (한국 플랫폼)
  // ===========================
  "Cafe24": {
    category: "E-commerce",
    icon: "☕",
    website: "https://www.cafe24.com",
    html: [/cafe24\.com/i, /cafe24api/i, /\/web\/upload/i, /EC-/i],
    scripts: [/cafe24\.com/i, /cafe24api/i],
    cookies: [/cafe24/i],
    headers: { "server": /cafe24/i },
    confidence: 90
  },

  "NHN Cloud": {
    category: "Cloud Platform",
    icon: "☁️",
    website: "https://www.nhncloud.com",
    headers: { "server": /NHN/i },
    html: [/nhncloud/i, /toast\.com/i],
    confidence: 75
  },

  "TOAST UI": {
    category: "JavaScript Library",
    icon: "🍞",
    website: "https://ui.toast.com",
    scripts: [/tui-/i, /toast-ui/i, /toastui/i],
    html: [/tui-editor/i, /tui-chart/i, /tui-calendar/i],
    confidence: 80
  },

  "Naver Analytics": {
    category: "Analytics",
    icon: "🟢",
    website: "https://analytics.naver.com",
    scripts: [/wcs_do\.js/i, /wcs\.naver\.com/i],
    html: [/wcs_do/i, /naver.*analytics/i],
    confidence: 85
  },

  "Naver Login": {
    category: "Authentication",
    icon: "🟢",
    website: "https://developers.naver.com",
    scripts: [/nid\.naver\.com/i, /naver.*login/i],
    html: [/naver.*login/i, /nid\.naver\.com/i],
    confidence: 80
  },

  "Kakao SDK": {
    category: "JavaScript Library",
    icon: "💬",
    website: "https://developers.kakao.com",
    scripts: [/developers\.kakao\.com\/sdk/i, /t1\.kakaocdn\.net/i, /dapi\.kakao\.com/i],
    html: [/kakao/i],
    js: { "Kakao": null },
    confidence: 85
  },

  "GABIA": {
    category: "Hosting",
    icon: "🌐",
    website: "https://www.gabia.com",
    headers: { "server": /gabia/i },
    html: [/gabia/i],
    confidence: 70
  },

  "XpressEngine": {
    category: "CMS",
    icon: "🇰🇷",
    website: "https://www.xpressengine.com",
    meta: { "generator": /XpressEngine/i },
    html: [/xe_official/i, /xpress.*engine/i, /xe-core/i],
    confidence: 85
  },

  "GNUBoard": {
    category: "CMS",
    icon: "🇰🇷",
    website: "https://www.gnuboard.com",
    html: [/gnuboard/i, /\/bbs\/login\.php/i, /\/adm\/admin/i, /g5_/i],
    implies: ["PHP"],
    confidence: 80
  },

  "KG이니시스": {
    category: "Payment",
    icon: "💳",
    website: "https://www.inicis.com",
    scripts: [/inicis/i, /stdpay/i, /inipay/i],
    html: [/inicis/i, /INIpay/i],
    confidence: 85
  },

  "NicePay": {
    category: "Payment",
    icon: "💳",
    website: "https://www.nicepay.co.kr",
    scripts: [/nicepay/i],
    html: [/nicepay/i],
    confidence: 80
  },

  "토스페이먼츠": {
    category: "Payment",
    icon: "💳",
    website: "https://www.tosspayments.com",
    scripts: [/tosspayments/i, /js\.tosspayments\.com/i],
    html: [/tosspayments/i],
    confidence: 85
  },

  // ===========================
  // Web Servers
  // ===========================
  "Nginx": {
    category: "Web Server",
    icon: "🟩",
    website: "https://nginx.org",
    cpe: "cpe:/a:nginx:nginx",
    headers: { "server": /nginx\/?(\S+)?/i },
    versionPatterns: { headers: { "server": /nginx\/([\d.]+)/i } },
    confidence: 95
  },

  "Apache": {
    category: "Web Server",
    icon: "🪶",
    website: "https://httpd.apache.org",
    cpe: "cpe:/a:apache:http_server",
    headers: { "server": /Apache\/?(\S+)?/i },
    versionPatterns: { headers: { "server": /Apache\/([\d.]+)/i } },
    confidence: 95
  },

  "IIS": {
    category: "Web Server",
    icon: "🪟",
    website: "https://www.iis.net",
    cpe: "cpe:/a:microsoft:iis",
    headers: { "server": /Microsoft-IIS\/([\d.]+)/i },
    versionPatterns: { headers: { "server": /Microsoft-IIS\/([\d.]+)/i } },
    implies: ["ASP.NET"],
    confidence: 95
  },

  "LiteSpeed": {
    category: "Web Server",
    icon: "⚡",
    website: "https://www.litespeedtech.com",
    headers: { "server": /LiteSpeed/i },
    confidence: 90
  },

  "OpenResty": {
    category: "Web Server",
    icon: "🟩",
    website: "https://openresty.org",
    headers: { "server": /openresty/i },
    implies: ["Nginx"],
    confidence: 90
  },

  "Tengine": {
    category: "Web Server",
    icon: "🟩",
    website: "https://tengine.taobao.org",
    headers: { "server": /Tengine/i },
    implies: ["Nginx"],
    confidence: 90
  },

  "Caddy": {
    category: "Web Server",
    icon: "🔒",
    website: "https://caddyserver.com",
    headers: { "server": /Caddy/i },
    confidence: 85
  },

  "Tomcat": {
    category: "Web Server",
    icon: "🐱",
    website: "https://tomcat.apache.org",
    cpe: "cpe:/a:apache:tomcat",
    headers: { "server": /Apache-Coyote/i },
    cookies: [/JSESSIONID/i],
    implies: ["Java"],
    confidence: 85
  },

  "Gunicorn": {
    category: "Web Server",
    icon: "🦄",
    website: "https://gunicorn.org",
    headers: { "server": /gunicorn/i },
    implies: ["Python"],
    confidence: 90
  },

  // ===========================
  // WAF & Security (보안 도구)
  // ===========================
  "Cloudflare WAF": {
    category: "WAF",
    icon: "🛡️",
    website: "https://www.cloudflare.com/waf/",
    headers: { "cf-ray": /.*/i, "cf-cache-status": /.*/i, "server": /cloudflare/i },
    cookies: [/__cflb/i, /__cfuid/i, /cf_clearance/i],
    confidence: 95
  },

  "AWS WAF": {
    category: "WAF",
    icon: "🛡️",
    website: "https://aws.amazon.com/waf/",
    headers: { "x-amzn-waf-action": /.*/i, "x-amzn-requestid": /.*/i },
    confidence: 80
  },

  "Imperva / Incapsula": {
    category: "WAF",
    icon: "🛡️",
    website: "https://www.imperva.com",
    headers: { "x-iinfo": /.*/i, "x-cdn": /Imperva/i },
    cookies: [/visid_incap_/i, /incap_ses_/i, /nlbi_/i],
    confidence: 90
  },

  "Sucuri": {
    category: "WAF",
    icon: "🛡️",
    website: "https://sucuri.net",
    headers: { "server": /Sucuri/i, "x-sucuri-id": /.*/i, "x-sucuri-cache": /.*/i },
    confidence: 90
  },

  "ModSecurity": {
    category: "WAF",
    icon: "🛡️",
    website: "https://modsecurity.org",
    headers: { "server": /mod_security/i, "x-mod-security": /.*/i },
    confidence: 85
  },

  "F5 BIG-IP": {
    category: "WAF",
    icon: "🛡️",
    website: "https://www.f5.com",
    headers: { "server": /BIG-IP/i, "x-wa-info": /.*/i },
    cookies: [/BIGipServer/i, /TS[a-f0-9]{8}/i],
    confidence: 85
  },

  "Akamai WAF": {
    category: "WAF",
    icon: "🛡️",
    website: "https://www.akamai.com",
    headers: { "server": /AkamaiGHost/i, "x-akamai-transformed": /.*/i, "akamai-grn": /.*/i },
    confidence: 85
  },

  "Azure Front Door": {
    category: "WAF",
    icon: "🛡️",
    website: "https://azure.microsoft.com/en-us/products/frontdoor",
    headers: { "x-azure-ref": /.*/i, "x-fd-healthprobe": /.*/i },
    confidence: 80
  },

  "Barracuda": {
    category: "WAF",
    icon: "🛡️",
    website: "https://www.barracuda.com",
    headers: { "server": /Barracuda/i },
    cookies: [/barra_counter_session/i],
    confidence: 80
  },

  "FortiWeb": {
    category: "WAF",
    icon: "🛡️",
    website: "https://www.fortinet.com",
    headers: { "server": /FortiWeb/i },
    cookies: [/FORTIWAFSID/i],
    confidence: 85
  },

  "Palo Alto": {
    category: "WAF",
    icon: "🛡️",
    website: "https://www.paloaltonetworks.com",
    headers: { "x-pan-": /.*/i },
    confidence: 70
  },

  "DDoS-Guard": {
    category: "WAF",
    icon: "🛡️",
    website: "https://ddos-guard.net",
    headers: { "server": /ddos-guard/i },
    confidence: 90
  },

  // ===========================
  // CDN
  // ===========================
  "Cloudflare": {
    category: "CDN",
    icon: "☁️",
    website: "https://www.cloudflare.com",
    headers: { "server": /cloudflare/i, "cf-ray": /.*/i },
    confidence: 95
  },

  "Amazon CloudFront": {
    category: "CDN",
    icon: "☁️",
    website: "https://aws.amazon.com/cloudfront/",
    headers: { "x-amz-cf-id": /.*/i, "x-amz-cf-pop": /.*/i, "server": /CloudFront/i, "via": /CloudFront/i },
    confidence: 95
  },

  "Fastly": {
    category: "CDN",
    icon: "⚡",
    website: "https://www.fastly.com",
    headers: { "x-served-by": /cache-/i, "x-fastly-request-id": /.*/i, "via": /varnish/i },
    confidence: 85
  },

  "Akamai": {
    category: "CDN",
    icon: "🌐",
    website: "https://www.akamai.com",
    headers: { "server": /AkamaiGHost/i, "x-akamai-transformed": /.*/i },
    confidence: 90
  },

  "KeyCDN": {
    category: "CDN",
    icon: "🔑",
    website: "https://www.keycdn.com",
    headers: { "server": /keycdn/i, "x-edge-location": /.*/i },
    confidence: 85
  },

  "StackPath": {
    category: "CDN",
    icon: "📦",
    website: "https://www.stackpath.com",
    headers: { "x-sp-": /.*/i, "server": /StackPath/i },
    confidence: 80
  },

  "Varnish": {
    category: "Caching",
    icon: "⚡",
    website: "https://varnish-cache.org",
    headers: { "via": /varnish/i, "x-varnish": /.*/i },
    confidence: 85
  },

  // ===========================
  // Programming Languages & Frameworks
  // ===========================
  "PHP": {
    category: "Programming Language",
    icon: "🐘",
    website: "https://www.php.net",
    cpe: "cpe:/a:php:php",
    headers: { "x-powered-by": /PHP\/([\d.]+)/i, "server": /PHP/i },
    cookies: [/PHPSESSID/i],
    html: [/\.php(?:\?|")/i],
    versionPatterns: { headers: { "x-powered-by": /PHP\/([\d.]+)/i } },
    confidence: 85
  },

  "Node.js": {
    category: "Programming Language",
    icon: "💚",
    website: "https://nodejs.org",
    headers: { "x-powered-by": /Express/i },
    confidence: 70
  },

  "Python": {
    category: "Programming Language",
    icon: "🐍",
    website: "https://www.python.org",
    headers: { "server": /Python/i, "x-powered-by": /(?:Flask|Django|FastAPI)/i },
    confidence: 75
  },

  "ASP.NET": {
    category: "Programming Language",
    icon: "🔵",
    website: "https://dotnet.microsoft.com",
    cpe: "cpe:/a:microsoft:asp.net",
    headers: { "x-powered-by": /ASP\.NET/i, "x-aspnet-version": /.*/i, "x-aspnetmvc-version": /.*/i },
    cookies: [/ASP\.NET_SessionId/i, /\.AspNetCore\./i, /__RequestVerificationToken/i],
    html: [/__VIEWSTATE/i, /__EVENTVALIDATION/i, /aspnetForm/i],
    versionPatterns: { headers: { "x-aspnet-version": /([\d.]+)/i } },
    confidence: 90
  },

  "Java": {
    category: "Programming Language",
    icon: "☕",
    website: "https://www.java.com",
    headers: { "x-powered-by": /(?:Servlet|JSP|JSF)/i },
    cookies: [/JSESSIONID/i],
    confidence: 75
  },

  "Ruby on Rails": {
    category: "Web Framework",
    icon: "💎",
    website: "https://rubyonrails.org",
    cpe: "cpe:/a:rubyonrails:rails",
    headers: { "x-powered-by": /Phusion Passenger/i, "x-runtime": /[\d.]+/i, "x-request-id": /[a-f0-9-]{36}/i },
    cookies: [/_session_id/i],
    html: [/csrf-token/i, /data-turbo/i, /turbolinks/i, /action=".*\.rb/i],
    meta: { "csrf-token": /.*/ },
    confidence: 80
  },

  "Django": {
    category: "Web Framework",
    icon: "🎸",
    website: "https://www.djangoproject.com",
    cpe: "cpe:/a:djangoproject:django",
    cookies: [/csrftoken/i, /django/i, /sessionid/i],
    html: [/csrfmiddlewaretoken/i, /__admin\//i],
    headers: { "x-frame-options": /DENY/i },
    implies: ["Python"],
    confidence: 80
  },

  "Flask": {
    category: "Web Framework",
    icon: "🧪",
    website: "https://flask.palletsprojects.com",
    headers: { "server": /Werkzeug/i },
    cookies: [/session=ey/i],
    implies: ["Python"],
    confidence: 80
  },

  "Laravel": {
    category: "Web Framework",
    icon: "🔺",
    website: "https://laravel.com",
    cpe: "cpe:/a:laravel:laravel",
    cookies: [/laravel_session/i, /XSRF-TOKEN/i],
    html: [/csrf-token.*content="/i],
    headers: { "set-cookie": /laravel_session/i },
    implies: ["PHP"],
    confidence: 85
  },

  "Spring": {
    category: "Web Framework",
    icon: "🌱",
    website: "https://spring.io",
    cpe: "cpe:/a:vmware:spring_framework",
    headers: { "x-application-context": /.*/i },
    cookies: [/JSESSIONID/i],
    html: [/spring/i],
    implies: ["Java"],
    confidence: 70
  },

  "Spring Boot": {
    category: "Web Framework",
    icon: "🌱",
    website: "https://spring.io/projects/spring-boot",
    headers: { "x-application-context": /.*/i },
    html: [/\/actuator/i, /\/swagger-ui/i],
    implies: ["Spring", "Java"],
    confidence: 75
  },

  "Express": {
    category: "Web Framework",
    icon: "🚂",
    website: "https://expressjs.com",
    headers: { "x-powered-by": /Express/i },
    implies: ["Node.js"],
    confidence: 90
  },

  "FastAPI": {
    category: "Web Framework",
    icon: "⚡",
    website: "https://fastapi.tiangolo.com",
    headers: { "server": /uvicorn/i },
    html: [/\/docs#\//i, /\/redoc/i, /openapi\.json/i],
    implies: ["Python"],
    confidence: 80
  },

  "Koa": {
    category: "Web Framework",
    icon: "🌿",
    website: "https://koajs.com",
    headers: { "x-powered-by": /koa/i },
    implies: ["Node.js"],
    confidence: 85
  },

  "Gin": {
    category: "Web Framework",
    icon: "🍸",
    website: "https://gin-gonic.com",
    headers: { "x-powered-by": /gin/i },
    confidence: 75
  },

  "CakePHP": {
    category: "Web Framework",
    icon: "🍰",
    website: "https://cakephp.org",
    cookies: [/cakephp/i],
    implies: ["PHP"],
    confidence: 80
  },

  "CodeIgniter": {
    category: "Web Framework",
    icon: "🔥",
    website: "https://codeigniter.com",
    cookies: [/ci_session/i, /csrf_cookie/i],
    headers: { "x-powered-by": /CodeIgniter/i },
    implies: ["PHP"],
    confidence: 80
  },

  "Symfony": {
    category: "Web Framework",
    icon: "🎵",
    website: "https://symfony.com",
    cookies: [/symfony/i],
    headers: { "x-debug-token": /.*/i, "x-debug-token-link": /.*/i },
    implies: ["PHP"],
    confidence: 80
  },

  // ===========================
  // Analytics & Marketing
  // ===========================
  "Google Analytics": {
    category: "Analytics",
    icon: "📊",
    website: "https://analytics.google.com",
    scripts: [/google-analytics\.com\/analytics\.js/i, /googletagmanager\.com\/gtag/i, /www\.google-analytics\.com\/ga\.js/i],
    html: [/google-analytics\.com/i, /UA-\d+-\d+/i, /G-[A-Z0-9]+/i, /gtag\s*\(\s*['"]config/i],
    js: { "ga": null, "gtag": null, "GoogleAnalyticsObject": null },
    confidence: 90
  },

  "Google Tag Manager": {
    category: "Tag Manager",
    icon: "🏷️",
    website: "https://tagmanager.google.com",
    scripts: [/googletagmanager\.com\/gtm\.js/i],
    html: [/GTM-[A-Z0-9]+/i, /google_tag_manager/i],
    js: { "google_tag_manager": null, "dataLayer": null },
    confidence: 90
  },

  "Facebook Pixel": {
    category: "Analytics",
    icon: "📘",
    website: "https://www.facebook.com/business",
    scripts: [/connect\.facebook\.net\/.*\/fbevents\.js/i],
    html: [/fbq\(/i, /facebook\.com\/tr/i, /fbevents\.js/i],
    js: { "fbq": null },
    confidence: 85
  },

  "Hotjar": {
    category: "Analytics",
    icon: "🔥",
    website: "https://www.hotjar.com",
    scripts: [/static\.hotjar\.com/i, /hotjar\.com\/c\/hotjar/i],
    js: { "hj": null, "hjSiteSettings": null },
    confidence: 85
  },

  "Mixpanel": {
    category: "Analytics",
    icon: "📊",
    website: "https://mixpanel.com",
    scripts: [/cdn\.mxpnl\.com/i, /mixpanel/i],
    js: { "mixpanel": null },
    confidence: 80
  },

  "Segment": {
    category: "Analytics",
    icon: "📊",
    website: "https://segment.com",
    scripts: [/cdn\.segment\.com/i, /analytics\.js/i],
    js: { "analytics": null },
    confidence: 75
  },

  "Amplitude": {
    category: "Analytics",
    icon: "📊",
    website: "https://amplitude.com",
    scripts: [/cdn\.amplitude\.com/i, /amplitude/i],
    js: { "amplitude": null },
    confidence: 80
  },

  "Heap": {
    category: "Analytics",
    icon: "📊",
    website: "https://heap.io",
    scripts: [/cdn\.heapanalytics\.com/i],
    js: { "heap": null },
    confidence: 80
  },

  "Clarity": {
    category: "Analytics",
    icon: "🔍",
    website: "https://clarity.microsoft.com",
    scripts: [/clarity\.ms/i],
    js: { "clarity": null },
    confidence: 85
  },

  "Matomo": {
    category: "Analytics",
    icon: "📊",
    website: "https://matomo.org",
    scripts: [/matomo\.js/i, /piwik\.js/i],
    js: { "_paq": null, "Matomo": null, "Piwik": null },
    confidence: 85
  },

  "Plausible": {
    category: "Analytics",
    icon: "📊",
    website: "https://plausible.io",
    scripts: [/plausible\.io\/js/i],
    confidence: 85
  },

  // ===========================
  // A/B Testing & Personalization
  // ===========================
  "Optimizely": {
    category: "A/B Testing",
    icon: "🧪",
    website: "https://www.optimizely.com",
    scripts: [/cdn\.optimizely\.com/i, /optimizely/i],
    js: { "optimizely": null },
    confidence: 85
  },

  "Google Optimize": {
    category: "A/B Testing",
    icon: "🧪",
    website: "https://optimize.google.com",
    scripts: [/googleoptimize\.com/i],
    html: [/google_optimize/i],
    confidence: 80
  },

  "VWO": {
    category: "A/B Testing",
    icon: "🧪",
    website: "https://vwo.com",
    scripts: [/dev\.visualwebsiteoptimizer\.com/i],
    js: { "_vwo": null },
    confidence: 80
  },

  "LaunchDarkly": {
    category: "Feature Flags",
    icon: "🚀",
    website: "https://launchdarkly.com",
    scripts: [/launchdarkly/i],
    confidence: 75
  },

  // ===========================
  // Security Tools
  // ===========================
  "reCAPTCHA": {
    category: "Security",
    icon: "🔒",
    website: "https://www.google.com/recaptcha",
    scripts: [/recaptcha\/api\.js/i, /recaptcha\/enterprise\.js/i, /gstatic\.com\/recaptcha/i],
    html: [/g-recaptcha/i, /recaptcha-token/i, /grecaptcha/i],
    js: { "grecaptcha": null },
    confidence: 90
  },

  "hCaptcha": {
    category: "Security",
    icon: "🔐",
    website: "https://www.hcaptcha.com",
    scripts: [/hcaptcha\.com\/1\/api\.js/i],
    html: [/h-captcha/i],
    confidence: 90
  },

  "Cloudflare Turnstile": {
    category: "Security",
    icon: "☁️",
    website: "https://www.cloudflare.com/products/turnstile/",
    scripts: [/challenges\.cloudflare\.com\/turnstile/i],
    html: [/cf-turnstile/i],
    confidence: 90
  },

  // ===========================
  // Authentication
  // ===========================
  "Auth0": {
    category: "Authentication",
    icon: "🔑",
    website: "https://auth0.com",
    scripts: [/auth0/i, /cdn\.auth0\.com/i],
    html: [/auth0/i],
    cookies: [/auth0/i],
    confidence: 80
  },

  "Firebase Authentication": {
    category: "Authentication",
    icon: "🔥",
    website: "https://firebase.google.com",
    scripts: [/firebase.*auth/i, /firebaseapp\.com/i],
    html: [/firebase/i],
    implies: ["Firebase"],
    confidence: 75
  },

  "Okta": {
    category: "Authentication",
    icon: "🔑",
    website: "https://www.okta.com",
    scripts: [/okta/i],
    html: [/okta/i],
    cookies: [/okta/i],
    confidence: 80
  },

  "Keycloak": {
    category: "Authentication",
    icon: "🔑",
    website: "https://www.keycloak.org",
    html: [/keycloak/i],
    cookies: [/KEYCLOAK/i, /KC_/i],
    confidence: 80
  },

  // ===========================
  // CRM & Customer Support
  // ===========================
  "Intercom": {
    category: "Customer Support",
    icon: "💬",
    website: "https://www.intercom.com",
    scripts: [/widget\.intercom\.io/i, /intercom/i],
    html: [/intercom-/i],
    js: { "Intercom": null },
    confidence: 85
  },

  "Zendesk": {
    category: "Customer Support",
    icon: "💬",
    website: "https://www.zendesk.com",
    scripts: [/static\.zdassets\.com/i, /zendesk/i],
    html: [/zendesk/i],
    js: { "zE": null, "Zendesk": null },
    confidence: 85
  },

  "Drift": {
    category: "Customer Support",
    icon: "💬",
    website: "https://www.drift.com",
    scripts: [/js\.driftt\.com/i, /drift/i],
    js: { "drift": null },
    confidence: 80
  },

  "Crisp": {
    category: "Customer Support",
    icon: "💬",
    website: "https://crisp.chat",
    scripts: [/client\.crisp\.chat/i],
    js: { "$crisp": null, "CRISP_WEBSITE_ID": null },
    confidence: 85
  },

  "Tawk.to": {
    category: "Customer Support",
    icon: "💬",
    website: "https://www.tawk.to",
    scripts: [/embed\.tawk\.to/i],
    js: { "Tawk_API": null },
    confidence: 85
  },

  "ChannelTalk": {
    category: "Customer Support",
    icon: "💬",
    website: "https://channel.io",
    scripts: [/cdn\.channel\.io/i, /channel\.io/i],
    js: { "ChannelIO": null },
    confidence: 85
  },

  "HubSpot": {
    category: "CRM",
    icon: "🟠",
    website: "https://www.hubspot.com",
    scripts: [/js\.hs-scripts\.com/i, /js\.hubspot\.com/i, /hbspt/i],
    html: [/hubspot/i, /hs-form/i],
    js: { "HubSpot": null, "hbspt": null },
    cookies: [/hubspot/i, /__hs/i],
    confidence: 85
  },

  "Salesforce": {
    category: "CRM",
    icon: "☁️",
    website: "https://www.salesforce.com",
    html: [/salesforce/i, /force\.com/i],
    scripts: [/salesforce/i],
    confidence: 75
  },

  // ===========================
  // Payment
  // ===========================
  "Stripe": {
    category: "Payment",
    icon: "💳",
    website: "https://stripe.com",
    scripts: [/js\.stripe\.com/i],
    html: [/stripe.*publishable/i],
    js: { "Stripe": null },
    confidence: 85
  },

  "PayPal": {
    category: "Payment",
    icon: "💰",
    website: "https://www.paypal.com",
    scripts: [/paypal\.com\/sdk/i, /paypalobjects\.com/i],
    js: { "paypal": null },
    confidence: 85
  },

  // ===========================
  // Font Services
  // ===========================
  "Google Fonts": {
    category: "Font",
    icon: "🔤",
    website: "https://fonts.google.com",
    html: [/fonts\.googleapis\.com/i, /fonts\.gstatic\.com/i],
    confidence: 85
  },

  "Font Awesome": {
    category: "Font",
    icon: "🎭",
    website: "https://fontawesome.com",
    html: [/font-awesome/i, /fontawesome/i, /fa-brands/i, /fa-solid/i, /fa-regular/i],
    scripts: [/fontawesome/i, /font-awesome/i],
    confidence: 85
  },

  "Adobe Fonts": {
    category: "Font",
    icon: "🔤",
    website: "https://fonts.adobe.com",
    html: [/use\.typekit\.net/i, /p\.typekit\.net/i],
    scripts: [/typekit/i],
    confidence: 85
  },

  // ===========================
  // Build Tools & Bundlers
  // ===========================
  "Webpack": {
    category: "Build Tool",
    icon: "📦",
    website: "https://webpack.js.org",
    scripts: [/webpack/i],
    html: [/webpackJsonp/i, /webpackChunk/i],
    js: { "webpackChunk": null, "webpackJsonp": null },
    confidence: 75
  },

  "Vite": {
    category: "Build Tool",
    icon: "⚡",
    website: "https://vitejs.dev",
    scripts: [/@vite\/client/i, /vite\/modulepreload/i],
    html: [/@vite\/client/i],
    confidence: 80
  },

  "Parcel": {
    category: "Build Tool",
    icon: "📦",
    website: "https://parceljs.org",
    scripts: [/parcel/i],
    confidence: 65
  },

  "esbuild": {
    category: "Build Tool",
    icon: "📦",
    website: "https://esbuild.github.io",
    html: [/esbuild/i],
    confidence: 60
  },

  "Turbopack": {
    category: "Build Tool",
    icon: "📦",
    website: "https://turbo.build/pack",
    html: [/turbopack/i],
    confidence: 70
  },

  // ===========================
  // PaaS & Cloud
  // ===========================
  "Vercel": {
    category: "PaaS",
    icon: "▲",
    website: "https://vercel.com",
    headers: { "x-vercel-id": /.*/i, "server": /Vercel/i, "x-vercel-cache": /.*/i },
    confidence: 95
  },

  "Netlify": {
    category: "PaaS",
    icon: "🌐",
    website: "https://www.netlify.com",
    headers: { "server": /Netlify/i, "x-nf-request-id": /.*/i },
    confidence: 95
  },

  "Heroku": {
    category: "PaaS",
    icon: "🟣",
    website: "https://www.heroku.com",
    headers: { "via": /vegur/i },
    confidence: 80
  },

  "AWS S3": {
    category: "Cloud Storage",
    icon: "☁️",
    website: "https://aws.amazon.com/s3/",
    headers: { "server": /AmazonS3/i, "x-amz-request-id": /.*/i },
    confidence: 90
  },

  "Google Cloud": {
    category: "Cloud Platform",
    icon: "☁️",
    website: "https://cloud.google.com",
    headers: { "server": /Google Frontend/i, "via": /google/i },
    confidence: 75
  },

  "Firebase": {
    category: "Cloud Platform",
    icon: "🔥",
    website: "https://firebase.google.com",
    html: [/firebaseapp\.com/i, /firebase\.js/i, /firebaseio\.com/i],
    scripts: [/firebase/i],
    confidence: 80
  },

  "Render": {
    category: "PaaS",
    icon: "🟢",
    website: "https://render.com",
    headers: { "server": /Render/i, "rndr-id": /.*/i },
    confidence: 85
  },

  "Railway": {
    category: "PaaS",
    icon: "🚂",
    website: "https://railway.app",
    headers: { "server": /railway/i },
    confidence: 80
  },

  "Fly.io": {
    category: "PaaS",
    icon: "✈️",
    website: "https://fly.io",
    headers: { "server": /Fly/i, "fly-request-id": /.*/i },
    confidence: 85
  },

  // ===========================
  // JavaScript Libraries
  // ===========================
  "Socket.IO": {
    category: "JavaScript Library",
    icon: "🔌",
    website: "https://socket.io",
    scripts: [/socket\.io(?:\.min)?\.js/i],
    js: { "io": null },
    confidence: 80
  },

  "Lodash": {
    category: "JavaScript Library",
    icon: "📚",
    website: "https://lodash.com",
    scripts: [/lodash(?:\.min)?\.js/i],
    js: { "_": null },
    confidence: 70
  },

  "Moment.js": {
    category: "JavaScript Library",
    icon: "⏰",
    website: "https://momentjs.com",
    scripts: [/moment(?:\.min)?\.js/i],
    js: { "moment": null },
    confidence: 75
  },

  "Three.js": {
    category: "JavaScript Library",
    icon: "🎮",
    website: "https://threejs.org",
    scripts: [/three(?:\.min)?\.js/i],
    js: { "THREE": null },
    confidence: 80
  },

  "D3.js": {
    category: "JavaScript Library",
    icon: "📈",
    website: "https://d3js.org",
    scripts: [/d3(?:\.min)?\.js/i, /d3@[\d]/i],
    js: { "d3": null },
    confidence: 80
  },

  "Chart.js": {
    category: "JavaScript Library",
    icon: "📈",
    website: "https://www.chartjs.org",
    scripts: [/chart(?:\.min)?\.js/i],
    js: { "Chart": null },
    confidence: 75
  },

  "Axios": {
    category: "JavaScript Library",
    icon: "📡",
    website: "https://axios-http.com",
    scripts: [/axios(?:\.min)?\.js/i],
    js: { "axios": null },
    confidence: 70
  },

  "GSAP": {
    category: "JavaScript Library",
    icon: "🎬",
    website: "https://greensock.com/gsap/",
    scripts: [/gsap(?:\.min)?\.js/i, /greensock/i],
    js: { "gsap": null, "TweenMax": null, "TweenLite": null },
    confidence: 80
  },

  "Swiper": {
    category: "JavaScript Library",
    icon: "👆",
    website: "https://swiperjs.com",
    scripts: [/swiper(?:\.min)?\.js/i, /swiper-bundle/i],
    html: [/swiper-container/i, /swiper-slide/i, /swiper-wrapper/i],
    js: { "Swiper": null },
    confidence: 80
  },

  "Lottie": {
    category: "JavaScript Library",
    icon: "🎬",
    website: "https://airbnb.design/lottie/",
    scripts: [/lottie(?:\.min)?\.js/i, /lottie-web/i, /bodymovin/i],
    html: [/lottie/i],
    confidence: 75
  },

  "Sentry": {
    category: "Error Tracking",
    icon: "🐛",
    website: "https://sentry.io",
    scripts: [/browser\.sentry-cdn\.com/i, /sentry/i],
    js: { "Sentry": null, "__SENTRY__": null },
    confidence: 80
  },

  "LogRocket": {
    category: "Error Tracking",
    icon: "🚀",
    website: "https://logrocket.com",
    scripts: [/cdn\.logrocket\.io/i, /logrocket/i],
    js: { "LogRocket": null },
    confidence: 80
  },

  "Datadog": {
    category: "Monitoring",
    icon: "🐶",
    website: "https://www.datadoghq.com",
    scripts: [/datadog/i, /dd-rum/i],
    js: { "DD_RUM": null },
    confidence: 80
  },

  "New Relic": {
    category: "Monitoring",
    icon: "📊",
    website: "https://newrelic.com",
    scripts: [/newrelic/i, /nr-data\.net/i, /bam\.nr-data\.net/i],
    js: { "newrelic": null, "NREUM": null },
    confidence: 80
  },

  "GraphQL": {
    category: "API",
    icon: "◆",
    website: "https://graphql.org",
    html: [/\/graphql/i],
    scripts: [/graphql/i],
    confidence: 70
  },

  "Elasticsearch": {
    category: "Search Engine",
    icon: "🔎",
    website: "https://www.elastic.co",
    html: [/elasticsearch/i, /elastic/i],
    headers: { "x-elastic-product": /.*/i },
    confidence: 70
  },

  "Algolia": {
    category: "Search Engine",
    icon: "🔎",
    website: "https://www.algolia.com",
    scripts: [/algoliasearch/i, /algolia/i],
    html: [/algolia/i],
    js: { "algoliasearch": null },
    confidence: 80
  },

  // ===========================
  // Database Hints
  // ===========================
  "MongoDB": {
    category: "Database",
    icon: "🍃",
    website: "https://www.mongodb.com",
    html: [/mongodb/i],
    cookies: [/mongo/i],
    headers: { "x-powered-by": /MongoDB/i },
    confidence: 60
  },

  "Redis": {
    category: "Database",
    icon: "🔴",
    website: "https://redis.io",
    headers: { "x-cache-engine": /redis/i },
    confidence: 55
  },

  // ===========================
  // Email Marketing
  // ===========================
  "Mailchimp": {
    category: "Email Marketing",
    icon: "📧",
    website: "https://mailchimp.com",
    scripts: [/chimpstatic\.com/i, /mailchimp/i, /list-manage\.com/i],
    html: [/mailchimp/i, /mc-embedded/i],
    confidence: 80
  },

  "SendGrid": {
    category: "Email Marketing",
    icon: "📧",
    website: "https://sendgrid.com",
    html: [/sendgrid/i],
    confidence: 65
  },

  // ===========================
  // Advertising
  // ===========================
  "Google Ads": {
    category: "Advertising",
    icon: "📢",
    website: "https://ads.google.com",
    scripts: [/pagead2\.googlesyndication\.com/i, /googleads\.g\.doubleclick\.net/i, /adservice\.google/i],
    html: [/google_ad_client/i, /data-ad-client/i],
    confidence: 85
  },

  "Google AdSense": {
    category: "Advertising",
    icon: "💰",
    website: "https://www.google.com/adsense",
    scripts: [/pagead2\.googlesyndication\.com\/pagead\/js\/adsbygoogle/i],
    html: [/adsbygoogle/i, /data-ad-slot/i],
    confidence: 85
  },

  // ===========================
  // Social & Widgets
  // ===========================
  "Twitter/X Widgets": {
    category: "Social",
    icon: "🐦",
    website: "https://developer.twitter.com",
    scripts: [/platform\.twitter\.com/i],
    html: [/twitter-/i, /tweet-/i],
    confidence: 80
  },

  "YouTube Embed": {
    category: "Media",
    icon: "📺",
    website: "https://youtube.com",
    html: [/youtube\.com\/embed/i, /youtube-nocookie\.com/i, /ytimg\.com/i],
    confidence: 80
  },

  // ===========================
  // State Management
  // ===========================
  "Redux": {
    category: "State Management",
    icon: "🔄",
    website: "https://redux.js.org",
    scripts: [/redux(?:\.min)?\.js/i],
    js: { "__REDUX_DEVTOOLS_EXTENSION__": null },
    implies: ["React"],
    confidence: 75
  },

  "MobX": {
    category: "State Management",
    icon: "🔄",
    website: "https://mobx.js.org",
    scripts: [/mobx/i],
    confidence: 65
  },

  "Zustand": {
    category: "State Management",
    icon: "🐻",
    website: "https://zustand-demo.pmnd.rs",
    scripts: [/zustand/i],
    implies: ["React"],
    confidence: 60
  },

  // ===========================
  // Containerization hints
  // ===========================
  "Docker": {
    category: "Container",
    icon: "🐳",
    website: "https://www.docker.com",
    headers: { "server": /docker/i },
    confidence: 60
  },

  "Kubernetes": {
    category: "Container",
    icon: "☸️",
    website: "https://kubernetes.io",
    headers: { "x-envoy-": /.*/i },
    confidence: 55
  },

  "Envoy": {
    category: "Proxy",
    icon: "🔀",
    website: "https://www.envoyproxy.io",
    headers: { "server": /envoy/i, "x-envoy-upstream-service-time": /.*/i },
    confidence: 85
  },

  "Traefik": {
    category: "Proxy",
    icon: "🔀",
    website: "https://traefik.io",
    headers: { "server": /Traefik/i },
    confidence: 85
  },

  // ===========================
  // Miscellaneous
  // ===========================
  "PWA": {
    category: "Technology",
    icon: "📱",
    website: "https://web.dev/progressive-web-apps/",
    html: [/manifest\.json/i, /service-worker/i, /serviceWorker/i],
    meta: { "theme-color": /.*/ },
    confidence: 70
  },

  "AMP": {
    category: "Technology",
    icon: "⚡",
    website: "https://amp.dev",
    html: [/<html[^>]*\bamp\b/i, /cdn\.ampproject\.org/i],
    confidence: 90
  },

  "WebAssembly": {
    category: "Technology",
    icon: "🔧",
    website: "https://webassembly.org",
    html: [/\.wasm/i],
    scripts: [/\.wasm/i],
    confidence: 65
  },

  "OpenGraph": {
    category: "Meta",
    icon: "🔗",
    website: "https://ogp.me",
    meta: { "og:title": /.*/, "og:type": /.*/ },
    confidence: 80
  },

  "JSON-LD": {
    category: "Meta",
    icon: "📋",
    website: "https://json-ld.org",
    html: [/type="application\/ld\+json"/i],
    confidence: 80
  }
};

// Export for use in other files
if (typeof module !== 'undefined') {
  module.exports = FINGERPRINTS;
}
