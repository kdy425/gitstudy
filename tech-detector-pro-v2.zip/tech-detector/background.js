/**
 * Background Service Worker v2.0
 * Captures HTTP headers, runs tech detection with confidence scoring,
 * calculates security score, manages history, and handles API calls
 */

importScripts("fingerprints.js");

// Stores
const headerStore = {};
const detectedTechs = {};
const pageSecurityStore = {};

// ===========================
// Header Capture
// ===========================
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.type === "main_frame") {
      const headers = {};
      details.responseHeaders.forEach((h) => {
        headers[h.name.toLowerCase()] = h.value || "";
      });
      headerStore[details.tabId] = headers;
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

chrome.tabs.onRemoved.addListener((tabId) => {
  delete headerStore[tabId];
  delete detectedTechs[tabId];
  delete pageSecurityStore[tabId];
});

// ===========================
// Technology Detection Engine
// ===========================
function matchFingerprint(name, fp, pageData, headers) {
  let matched = false;
  let version = null;
  const evidence = [];
  let confidenceBoost = 0;

  const scriptSrcs = (pageData.scriptSrcs || pageData.scripts || []).map(s => typeof s === 'string' ? s : (s.src || ''));

  // Check scripts
  if (fp.scripts && scriptSrcs.length > 0) {
    for (const pattern of fp.scripts) {
      for (const src of scriptSrcs) {
        const m = src.match(pattern);
        if (m) {
          matched = true;
          evidence.push(`Script: ${src.substring(0, 100)}`);
          confidenceBoost += 10;
          break;
        }
      }
      if (matched) break;
    }
  }

  // Check HTML patterns
  if (fp.html && pageData.html) {
    for (const pattern of fp.html) {
      const m = pageData.html.match(pattern);
      if (m) {
        matched = true;
        evidence.push(`HTML: ${m[0].substring(0, 80)}`);
        confidenceBoost += 5;
        break;
      }
    }
  }

  // Check meta tags
  if (fp.meta && pageData.metas) {
    for (const [metaName, pattern] of Object.entries(fp.meta)) {
      const content = pageData.metas[metaName.toLowerCase()];
      if (content !== undefined) {
        const m = String(content).match(pattern);
        if (m) {
          matched = true;
          evidence.push(`Meta: ${metaName}="${String(content).substring(0, 60)}"`);
          confidenceBoost += 15;
        }
      }
    }
  }

  // Check HTTP headers
  if (fp.headers && headers) {
    for (const [headerName, pattern] of Object.entries(fp.headers)) {
      const value = headers[headerName.toLowerCase()];
      if (value) {
        const m = value.match(pattern);
        if (m) {
          matched = true;
          evidence.push(`Header: ${headerName}: ${value.substring(0, 80)}`);
          confidenceBoost += 15;
        }
      }
    }
  }

  // Check cookies
  if (fp.cookies && pageData.cookies) {
    for (const pattern of fp.cookies) {
      if (pageData.cookies.match(pattern)) {
        matched = true;
        evidence.push(`Cookie: ${pattern.source}`);
        confidenceBoost += 8;
        break;
      }
    }
  }

  // Check JS globals
  if (fp.js && pageData.jsGlobals) {
    for (const [varName, _] of Object.entries(fp.js)) {
      if (pageData.jsGlobals[varName]) {
        matched = true;
        evidence.push(`JS Global: ${varName}`);
        confidenceBoost += 12;
        break;
      }
    }
  }

  // Check inline scripts
  if (!matched && fp.scripts && pageData.inlineScripts) {
    for (const pattern of fp.scripts) {
      for (const inline of pageData.inlineScripts) {
        if (inline.match(pattern)) {
          matched = true;
          evidence.push(`Inline script match`);
          confidenceBoost += 5;
          break;
        }
      }
      if (matched) break;
    }
  }

  // Check stylesheets
  if (!matched && fp.scripts && pageData.stylesheets) {
    for (const pattern of fp.scripts) {
      for (const css of pageData.stylesheets) {
        if (css.match(pattern)) {
          matched = true;
          evidence.push(`Stylesheet: ${css.substring(0, 80)}`);
          confidenceBoost += 5;
          break;
        }
      }
      if (matched) break;
    }
  }

  // Check resource hints (preconnect / dns-prefetch)
  if (!matched && fp.scripts && pageData.resourceHints) {
    for (const pattern of fp.scripts) {
      for (const hint of pageData.resourceHints) {
        if (hint.match(pattern)) {
          matched = true;
          evidence.push(`Resource hint: ${hint}`);
          confidenceBoost += 3;
          break;
        }
      }
      if (matched) break;
    }
  }

  // Extract version
  if (matched && fp.versionPatterns) {
    version = extractVersion(fp.versionPatterns, pageData, headers);
    if (version) confidenceBoost += 10;
  }

  // Calculate final confidence
  let confidence = fp.confidence || 50;
  confidence = Math.min(100, confidence + Math.min(confidenceBoost, 25));

  return { matched, version, evidence, confidence };
}

function extractVersion(vp, pageData, headers) {
  const scriptSrcs = (pageData.scriptSrcs || pageData.scripts || []).map(s => typeof s === 'string' ? s : (s.src || ''));

  // Headers
  if (vp.headers && headers) {
    for (const [headerName, pattern] of Object.entries(vp.headers)) {
      const value = headers[headerName.toLowerCase()];
      if (value) {
        const m = value.match(pattern);
        if (m && m[1]) return m[1];
      }
    }
  }
  // Meta
  if (vp.meta && pageData.metas) {
    for (const [metaName, pattern] of Object.entries(vp.meta)) {
      const content = pageData.metas[metaName.toLowerCase()];
      if (content) {
        const m = content.match(pattern);
        if (m && m[1]) return m[1];
      }
    }
  }
  // Scripts
  if (vp.scripts && scriptSrcs.length > 0) {
    for (const pattern of vp.scripts) {
      for (const src of scriptSrcs) {
        const m = src.match(pattern);
        if (m && m[1]) return m[1];
      }
    }
  }
  // HTML
  if (vp.html && pageData.html) {
    for (const pattern of vp.html) {
      const m = pageData.html.match(pattern);
      if (m && m[1]) return m[1];
    }
  }
  // JS globals
  if (vp.js && pageData.jsGlobals) {
    for (const [varName, _] of Object.entries(vp.js)) {
      const val = pageData.jsGlobals[varName];
      if (val && typeof val === "string") return val;
    }
  }
  return null;
}

/**
 * Run full detection
 */
function detectTechnologies(pageData, headers) {
  const results = [];
  const matchedNames = new Set();

  for (const [name, fp] of Object.entries(FINGERPRINTS)) {
    const { matched, version, evidence, confidence } = matchFingerprint(name, fp, pageData, headers);

    if (matched) {
      matchedNames.add(name);
      results.push({
        name,
        version: version || null,
        category: fp.category,
        icon: fp.icon,
        website: fp.website,
        implies: fp.implies || [],
        excludes: fp.excludes || [],
        cpe: fp.cpe || null,
        evidence,
        confidence
      });
    }
  }

  // Add implied technologies
  const impliedNames = new Set();
  results.forEach((r) => {
    r.implies.forEach((imp) => impliedNames.add(imp));
  });

  impliedNames.forEach((impName) => {
    if (!matchedNames.has(impName) && FINGERPRINTS[impName]) {
      const fp = FINGERPRINTS[impName];
      results.push({
        name: impName,
        version: null,
        category: fp.category,
        icon: fp.icon,
        website: fp.website,
        implies: [],
        excludes: [],
        cpe: fp.cpe || null,
        evidence: ["Implied by detected technology"],
        confidence: Math.min((fp.confidence || 50), 60),
        implied: true
      });
      matchedNames.add(impName);
    }
  });

  // Sort by confidence desc
  results.sort((a, b) => b.confidence - a.confidence);

  return results;
}

// ===========================
// Security Score Calculator
// ===========================
function calculateSecurityScore(headers, pageSecurity) {
  let score = 100;
  const findings = [];

  // Security headers check
  const secHeaders = {
    "content-security-policy": { weight: 15, label: "Content-Security-Policy" },
    "strict-transport-security": { weight: 12, label: "Strict-Transport-Security (HSTS)" },
    "x-content-type-options": { weight: 8, label: "X-Content-Type-Options" },
    "x-frame-options": { weight: 8, label: "X-Frame-Options" },
    "referrer-policy": { weight: 5, label: "Referrer-Policy" },
    "permissions-policy": { weight: 5, label: "Permissions-Policy" },
    "cross-origin-opener-policy": { weight: 4, label: "Cross-Origin-Opener-Policy" },
    "cross-origin-embedder-policy": { weight: 3, label: "Cross-Origin-Embedder-Policy" },
    "cross-origin-resource-policy": { weight: 3, label: "Cross-Origin-Resource-Policy" },
    "x-xss-protection": { weight: 2, label: "X-XSS-Protection (deprecated but present)" }
  };

  for (const [header, info] of Object.entries(secHeaders)) {
    if (!headers[header]) {
      score -= info.weight;
      findings.push({
        type: "missing_header",
        severity: info.weight >= 10 ? "high" : info.weight >= 5 ? "medium" : "low",
        header: info.label,
        message: `${info.label} 헤더 미설정`
      });
    }
  }

  // CSP analysis
  if (headers["content-security-policy"]) {
    const csp = headers["content-security-policy"];
    if (csp.includes("'unsafe-inline'")) {
      score -= 5;
      findings.push({ type: "weak_csp", severity: "medium", message: "CSP: unsafe-inline 허용됨" });
    }
    if (csp.includes("'unsafe-eval'")) {
      score -= 5;
      findings.push({ type: "weak_csp", severity: "medium", message: "CSP: unsafe-eval 허용됨" });
    }
    if (csp.includes("*") && !csp.includes("*.")) {
      score -= 3;
      findings.push({ type: "weak_csp", severity: "low", message: "CSP: 와일드카드(*) 사용" });
    }
  }

  // HSTS analysis
  if (headers["strict-transport-security"]) {
    const hsts = headers["strict-transport-security"];
    const maxAgeMatch = hsts.match(/max-age=(\d+)/);
    if (maxAgeMatch) {
      const maxAge = parseInt(maxAgeMatch[1]);
      if (maxAge < 31536000) {
        score -= 3;
        findings.push({ type: "weak_hsts", severity: "low", message: `HSTS max-age가 1년 미만 (${maxAge}초)` });
      }
      if (!hsts.includes("includeSubDomains")) {
        findings.push({ type: "info", severity: "info", message: "HSTS: includeSubDomains 미포함" });
      }
      if (!hsts.includes("preload")) {
        findings.push({ type: "info", severity: "info", message: "HSTS: preload 미포함" });
      }
    }
  }

  // Server banner (information disclosure)
  if (headers["server"]) {
    const serverVal = headers["server"];
    if (/[\d.]+/.test(serverVal)) {
      score -= 3;
      findings.push({ type: "info_disclosure", severity: "low", message: `서버 버전 노출: ${serverVal}` });
    }
  }

  if (headers["x-powered-by"]) {
    score -= 3;
    findings.push({ type: "info_disclosure", severity: "low", message: `X-Powered-By 노출: ${headers["x-powered-by"]}` });
  }

  if (headers["x-aspnet-version"]) {
    score -= 3;
    findings.push({ type: "info_disclosure", severity: "low", message: `ASP.NET 버전 노출: ${headers["x-aspnet-version"]}` });
  }

  // Cookie security
  const setCookie = headers["set-cookie"] || "";
  if (setCookie) {
    if (!setCookie.toLowerCase().includes("secure")) {
      score -= 3;
      findings.push({ type: "cookie_security", severity: "medium", message: "Set-Cookie: Secure 플래그 누락" });
    }
    if (!setCookie.toLowerCase().includes("httponly")) {
      score -= 3;
      findings.push({ type: "cookie_security", severity: "medium", message: "Set-Cookie: HttpOnly 플래그 누락" });
    }
    if (!setCookie.toLowerCase().includes("samesite")) {
      score -= 2;
      findings.push({ type: "cookie_security", severity: "low", message: "Set-Cookie: SameSite 플래그 누락" });
    }
  }

  // Page-level security from content script
  if (pageSecurity) {
    if (!pageSecurity.https) {
      score -= 15;
      findings.push({ type: "no_https", severity: "critical", message: "HTTPS 미사용" });
    }
    if (pageSecurity.mixedContent) {
      score -= 8;
      findings.push({ type: "mixed_content", severity: "high", message: "Mixed Content 감지" });
    }
    if (pageSecurity.dangerousInlineHandlers > 5) {
      score -= 3;
      findings.push({ type: "inline_handlers", severity: "low", message: `인라인 이벤트 핸들러 ${pageSecurity.dangerousInlineHandlers}개 감지 (XSS surface)` });
    }
    if (pageSecurity.externalScriptsWithoutSRI > 0) {
      score -= 2;
      findings.push({ type: "no_sri", severity: "low", message: `SRI 없는 외부 스크립트 ${pageSecurity.externalScriptsWithoutSRI}/${pageSecurity.externalScriptsTotal}개` });
    }
  }

  score = Math.max(0, Math.min(100, score));

  let grade;
  if (score >= 90) grade = "A+";
  else if (score >= 80) grade = "A";
  else if (score >= 70) grade = "B";
  else if (score >= 60) grade = "C";
  else if (score >= 50) grade = "D";
  else grade = "F";

  return { score, grade, findings };
}

// ===========================
// History Management
// ===========================
async function saveToHistory(hostname, techs, securityScore) {
  try {
    const result = await chrome.storage.local.get(["scanHistory"]);
    const history = result.scanHistory || [];
    
    history.unshift({
      hostname,
      timestamp: Date.now(),
      techCount: techs.length,
      technologies: techs.map(t => ({ name: t.name, version: t.version, category: t.category, confidence: t.confidence })),
      securityGrade: securityScore?.grade || "N/A"
    });

    // Keep last 200 entries
    if (history.length > 200) history.length = 200;
    
    await chrome.storage.local.set({ scanHistory: history });
  } catch (e) {
    console.debug("[TechDetector] History save failed:", e);
  }
}

// ===========================
// Perplexity API
// ===========================
async function checkVulnerabilities(technologies, apiKey) {
  const techsWithVersions = technologies.filter((t) => t.version);

  if (techsWithVersions.length === 0) {
    return { results: [], message: "버전 정보가 있는 기술이 없어 취약점 확인이 불가합니다." };
  }

  const techList = techsWithVersions.map((t) => `${t.name} ${t.version}`).join(", ");

  const prompt = `As a cybersecurity expert, analyze these web technologies for known CVEs. Be specific and accurate.

Technologies: ${techList}

For each technology provide JSON:
[{"name":"tech","version":"x.x","risk":"CRITICAL|HIGH|MEDIUM|LOW|SAFE","cves":["CVE-XXXX-XXXXX"],"cvss_scores":[9.8],"latest_version":"x.x.x","summary":"brief description","exploit_available":true/false,"patch_available":true/false}]

Only respond with the JSON array.`;

  try {
    const response = await fetch("https://api.perplexity.ai/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "sonar",
        messages: [
          { role: "system", content: "You are a cybersecurity vulnerability analyst. Respond with valid JSON only. No markdown." },
          { role: "user", content: prompt }
        ],
        max_tokens: 3000,
        temperature: 0.1
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`API error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content.trim();
    
    let vulnResults;
    try {
      const cleaned = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      vulnResults = JSON.parse(cleaned);
    } catch (e) {
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        vulnResults = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("Failed to parse response as JSON");
      }
    }

    return { results: vulnResults, raw: content };
  } catch (error) {
    return { error: error.message, results: [] };
  }
}

// ===========================
// Export Functions
// ===========================
function exportAsJSON(tabId) {
  const techs = detectedTechs[tabId] || [];
  const headers = headerStore[tabId] || {};
  const security = pageSecurityStore[tabId] || {};
  
  return JSON.stringify({
    exportDate: new Date().toISOString(),
    technologies: techs,
    headers,
    securityAnalysis: security
  }, null, 2);
}

function exportAsCSV(tabId) {
  const techs = detectedTechs[tabId] || [];
  let csv = "Technology,Version,Category,Confidence,Evidence\n";
  
  techs.forEach(t => {
    const ev = (t.evidence || []).join("; ").replace(/"/g, '""');
    csv += `"${t.name}","${t.version || 'N/A'}","${t.category}","${t.confidence}%","${ev}"\n`;
  });
  
  return csv;
}

// ===========================
// Message Handler
// ===========================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "PAGE_DATA") {
    const tabId = sender.tab?.id;
    if (tabId) {
      const headers = headerStore[tabId] || {};
      const techs = detectTechnologies(msg.data, headers);
      detectedTechs[tabId] = techs;
      
      const securityScore = calculateSecurityScore(headers, msg.data.pageSecurity);
      pageSecurityStore[tabId] = securityScore;

      // Save to history
      const hostname = msg.data.hostname || "unknown";
      saveToHistory(hostname, techs, securityScore);

      // Update badge
      chrome.action.setBadgeText({ text: techs.length > 0 ? String(techs.length) : "", tabId });
      chrome.action.setBadgeBackgroundColor({ color: "#6366f1", tabId });
    }
  }

  if (msg.type === "GET_RESULTS") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      sendResponse({
        technologies: detectedTechs[tabId] || [],
        headers: headerStore[tabId] || {},
        securityScore: pageSecurityStore[tabId] || null
      });
    });
    return true;
  }

  if (msg.type === "CHECK_VULNS") {
    chrome.storage.sync.get(["perplexityApiKey"], async (result) => {
      const apiKey = result.perplexityApiKey;
      if (!apiKey) {
        sendResponse({ error: "Perplexity API 키가 설정되지 않았습니다." });
        return;
      }
      const vulnResult = await checkVulnerabilities(msg.technologies, apiKey);
      sendResponse(vulnResult);
    });
    return true;
  }

  if (msg.type === "SAVE_API_KEY") {
    chrome.storage.sync.set({ perplexityApiKey: msg.apiKey }, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "GET_API_KEY") {
    chrome.storage.sync.get(["perplexityApiKey"], (result) => sendResponse({ apiKey: result.perplexityApiKey || "" }));
    return true;
  }

  if (msg.type === "RESCAN_PAGE") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: "RESCAN" }, () => sendResponse({ ok: true }));
      }
    });
    return true;
  }

  if (msg.type === "EXPORT_JSON") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      sendResponse({ data: exportAsJSON(tabId) });
    });
    return true;
  }

  if (msg.type === "EXPORT_CSV") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      sendResponse({ data: exportAsCSV(tabId) });
    });
    return true;
  }

  if (msg.type === "GET_HISTORY") {
    chrome.storage.local.get(["scanHistory"], (result) => {
      sendResponse({ history: result.scanHistory || [] });
    });
    return true;
  }

  if (msg.type === "CLEAR_HISTORY") {
    chrome.storage.local.set({ scanHistory: [] }, () => sendResponse({ ok: true }));
    return true;
  }
});
