"""
HandsPlus Interactive Packet Interceptor v5.4

구조:
  - stdin_thread: readline → event_queue
  - frida callback: 패킷 → event_queue (stdout 출력 안 함)
  - main_thread: event_queue 소비, 모든 출력/입력 처리

사용법:
    python frida_intercept_controller.py
    python frida_intercept_controller.py --spawn
"""

import frida
import sys
import argparse
import threading
import json
import queue

PACKAGE = "com.nexon.handsplus"
SCRIPT_PATH = "frida_intercept.js"

try:
    import colorama
    colorama.init()
except ImportError:
    pass

RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"

show_hex = False

# ── 이벤트 큐 (모든 이벤트가 여기로) ──
event_queue = queue.Queue()

# 이벤트 타입
EVT_INPUT = "input"         # stdin 입력
EVT_PACKET = "packet"       # frida 인터셉트 패킷
EVT_LOG = "log"             # frida 일반 로그
EVT_ERROR = "error"         # frida 에러

# ── 상태 ──
STATE_CMD = "cmd"
STATE_INTERCEPT = "intercept"
STATE_MODIFY = "modify"


def format_hexdump(hex_str):
    data = bytes.fromhex(hex_str)
    lines = []
    for i in range(0, len(data), 16):
        chunk = data[i:i + 16]
        hex_part = " ".join(f"{b:02x}" for b in chunk[:8])
        if len(chunk) > 8:
            hex_part += "  " + " ".join(f"{b:02x}" for b in chunk[8:])
        hex_part = hex_part.ljust(50)
        ascii_part = "".join(chr(b) if 0x20 <= b <= 0x7E else "." for b in chunk)
        lines.append(f"  {i:04x}  {hex_part} |{ascii_part}|")
    return "\n".join(lines)


def format_fields(fields):
    if not fields:
        return "  (no fields)"
    lines = []
    for f in fields:
        t, idx = f.get("t", "?"), f.get("i", 0)
        name, display = f.get("n", ""), f.get("d", "")
        label = f" {DIM}[{name}]{RESET}" if name else ""
        lines.append(f"  {CYAN}{t}#{idx}{RESET}{label}: {display}")
    return "\n".join(lines)


def stdin_reader():
    """stdin → event_queue (별도 스레드)"""
    try:
        while True:
            line = sys.stdin.readline()
            if not line:
                event_queue.put((EVT_INPUT, None))
                break
            event_queue.put((EVT_INPUT, line.rstrip("\n\r")))
    except Exception:
        event_queue.put((EVT_INPUT, None))


class App:
    def __init__(self, session, script_path):
        self.session = session
        self.state = STATE_CMD
        self.current_pkt = None
        self.mod_hex_list = None
        self.mod_modified = False
        self.mod_hex_modified = False   # offset/hex 직접 수정 여부
        self.pending_rules = []  # 규칙 대기열
        self.response_event = threading.Event()
        self.response_hex = None

        with open(script_path, "r", encoding="utf-8") as f:
            self.script = session.create_script(f.read())
        self.script.on("message", self._on_message)

    def start(self):
        self.script.load()
        print(f"{GREEN}[✓] Interceptor loaded{RESET}")
        print(f"  {DIM}help 으로 명령어 확인{RESET}\n")

    def _on_message(self, message, data):
        """frida 콜백 - event_queue에 넣기만 함"""
        msg_type = message.get("type")

        if msg_type == "send":
            payload = message["payload"]
            if isinstance(payload, dict) and payload.get("type") == "intercept":
                event_queue.put((EVT_PACKET, payload))
                self.response_event.wait()
                self.response_event.clear()
                self.script.post({"type": "response", "payload": self.response_hex})
                # ★ flush_rules는 메인 스레드에서 처리 (여기서 하면 데드락)
            else:
                event_queue.put((EVT_LOG, str(payload)))

        elif msg_type == "log":
            # ★ console.log() 출력
            level = message.get("level", "info")
            text = message.get("payload", "")
            event_queue.put((EVT_LOG, text))

        elif msg_type == "error":
            event_queue.put((EVT_ERROR, message.get("stack", str(message))))

    def send_response(self, hex_data):
        """메인 스레드 → frida 콜백 스레드로 응답"""
        self.response_hex = hex_data
        self.response_event.set()

    def _flush_rules(self):
        for rule in self.pending_rules:
            try:
                rule["fn"](*rule["args"])
            except Exception:
                pass
        self.pending_rules.clear()

    def _has_hex_mod(self):
        return self.mod_hex_modified

    # ════════════════════════════════════════
    # 이벤트 처리
    # ════════════════════════════════════════
    def process_event(self, evt_type, evt_data):
        if evt_type == EVT_LOG:
            print(f"\r{evt_data}")
            self._show_prompt()
            return True

        if evt_type == EVT_ERROR:
            print(f"\r{RED}[ERR] {evt_data}{RESET}")
            self._show_prompt()
            return True

        if evt_type == EVT_PACKET:
            self._on_packet(evt_data)
            return True

        if evt_type == EVT_INPUT:
            if evt_data is None:
                return False  # EOF
            self._on_input(evt_data)
            return True

        return True

    def _show_prompt(self):
        if self.state == STATE_CMD:
            print(f"{BOLD}cmd>{RESET} ", end="", flush=True)
        elif self.state == STATE_INTERCEPT:
            print(f" forward[f] modify[m] drop[d] hex[h] > ", end="", flush=True)
        elif self.state == STATE_MODIFY:
            print(f"{YELLOW}mod>{RESET} ", end="", flush=True)

    # ── 패킷 도착 ──
    def _on_packet(self, pkt):
        self.current_pkt = pkt
        self.state = STATE_INTERCEPT

        direction = "▶ OUT →" if pkt["direction"] == "outgoing" else "◀ IN  ←"
        color = YELLOW if pkt["direction"] == "outgoing" else CYAN
        fields = pkt.get("fields", [])

        print(f"\n{color}{'─'*55}")
        print(f" {direction}  {pkt['packetName']}  |  {pkt['size']}B  |  {pkt['timestamp']}")
        print(f"{'─'*55}{RESET}")
        print(format_fields(fields))
        if show_hex:
            print(format_hexdump(pkt["hex"]))

        self._show_prompt()

    # ── stdin 입력 ──
    def _on_input(self, line):
        if self.state == STATE_CMD:
            self._handle_cmd(line.strip())
            self._show_prompt()

        elif self.state == STATE_INTERCEPT:
            self._handle_intercept(line.strip())

        elif self.state == STATE_MODIFY:
            self._handle_modify(line.strip())

    # ════════════════════════════════════════
    # INTERCEPT
    # ════════════════════════════════════════
    def _handle_intercept(self, choice):
        pkt = self.current_pkt
        choice = choice.lower()

        if choice in ("f", "forward", ""):
            print(f"  {GREEN}→ forward{RESET}")
            self._finish(pkt["hex"])

        elif choice in ("d", "drop"):
            print(f"  {RED}→ drop{RESET}")
            self._finish("DROP")

        elif choice in ("h", "hex"):
            print(format_hexdump(pkt["hex"]))
            self._show_prompt()

        elif choice in ("m", "modify"):
            self.state = STATE_MODIFY
            self.mod_hex_list = list(bytes.fromhex(pkt["hex"]))
            self.mod_modified = False
            self.mod_hex_modified = False
            print(f"\n{YELLOW}── 수정 모드 ──{RESET}")
            print(f"  필드: {BOLD}S#1=새값{RESET}  {BOLD}E4#2=999{RESET}")
            print(f"  HEX:  {BOLD}4:ff 5:01{RESET}    전체: {BOLD}hex 문자열{RESET}")
            print(f"  {DIM}enter=적용  cancel=취소  show=필드{RESET}")
            self._show_prompt()

        else:
            print(f"  {DIM}f/m/d/h{RESET}")
            self._show_prompt()

    # ════════════════════════════════════════
    # MODIFY
    # ════════════════════════════════════════
    def _handle_modify(self, line):
        pkt = self.current_pkt
        fields = pkt.get("fields", [])

        # 빈 줄
        if not line:
            if self.mod_modified:
                # offset 수정이 있으면 적용, 필드 수정만이면 intercept로 돌아감
                if self._has_hex_mod():
                    result = bytes(self.mod_hex_list).hex()
                    print(f"  {GREEN}✓ hex 수정 적용 → forward{RESET}")
                    self._finish(result)
                else:
                    # 필드 규칙만 등록됨 → intercept로 돌아감
                    self.state = STATE_INTERCEPT
                    print(f"\n  {DIM}규칙 예약 완료. 현재 패킷 처리:{RESET}")
                    print(f"  {BOLD}[f]{RESET} forward (원본)  {BOLD}[d]{RESET} drop (다음 패킷에 규칙 적용)")
                    self._show_prompt()
            else:
                print(f"  {GREEN}→ forward{RESET}")
                self._finish(pkt["hex"])
            return

        if line.lower() == "cancel":
            print(f"  취소 → forward")
            self._finish(pkt["hex"])
            return

        if line.lower() == "show":
            print(format_fields(fields))
            self._show_prompt()
            return

        if line.lower().startswith("hex "):
            new_hex = line[4:].strip().replace(" ", "")
            try:
                bytes.fromhex(new_hex)
                print(f"  {GREEN}✓ hex 교체 ({len(new_hex) // 2}B){RESET}")
                self._finish(new_hex)
            except ValueError:
                print(f"  {RED}유효하지 않은 hex{RESET}")
                self._show_prompt()
            return

        # ── 필드 기반: E4#1=999, S#1=텍스트 ──
        if "#" in line and "=" in line:
            handled = self._modify_field(line, pkt, fields)
            if handled:
                self._show_prompt()
                return

        # ── offset:value ──
        try:
            for pair in line.split():
                sep = ":" if ":" in pair else "="
                off_str, val_str = pair.split(sep, 1)
                offset = int(off_str)
                val = int(val_str, 16)
                if 0 <= offset < len(self.mod_hex_list):
                    old = self.mod_hex_list[offset]
                    self.mod_hex_list[offset] = val
                    print(f"  [{offset}] 0x{old:02x} → 0x{val:02x}")
                    self.mod_modified = True
                    self.mod_hex_modified = True
                else:
                    print(f"  {RED}offset {offset} 범위 초과{RESET}")
        except Exception as e:
            print(f"  {RED}오류: {e}{RESET}")

        self._show_prompt()

    def _modify_field(self, line, pkt, fields):
        """필드 기반 수정. 성공 시 True"""
        try:
            ref, val = line.split("=", 1)
            ref = ref.strip().upper()
            val = val.strip()
            pid = pkt["packetId"]

            for f in fields:
                field_ref = f"{f['t']}#{f['i']}".upper()
                if field_ref == ref:
                    old_val = f.get("d", f.get("v", ""))
                    name = f.get("n", "")
                    label = f" [{name}]" if name else ""
                    ft, fi = f["t"], f["i"]

                    if ft == "S":
                        old_str = f.get("v", "")
                        self.pending_rules.append({
                            "fn": self.script.exports_sync.add_string_rule,
                            "args": (pid, old_str, val)
                        })
                        print(f"  {ref}{label}: {old_val} → {GREEN}{val}{RESET}")
                        print(f"  {DIM}→ str rule 예약됨{RESET}")
                    elif ft in ("E1", "E4", "E8"):
                        func_map = {
                            "E1": self.script.exports_sync.add_encode1_rule,
                            "E4": self.script.exports_sync.add_encode4_rule,
                            "E8": self.script.exports_sync.add_encode8_rule,
                        }
                        self.pending_rules.append({
                            "fn": func_map[ft],
                            "args": (pid, fi, int(val, 0))
                        })
                        print(f"  {ref}{label}: {old_val} → {GREEN}{val}{RESET}")
                        print(f"  {DIM}→ {ft} rule 예약됨{RESET}")
                    else:
                        print(f"  {RED}{ft} 수정 미지원{RESET}")
                        return True

                    self.mod_modified = True
                    return True

            print(f"  {RED}필드 {ref} 없음 (show){RESET}")
            return True
        except Exception as e:
            print(f"  {RED}필드 파싱 오류: {e}{RESET}")
            return True

    def _finish(self, hex_data):
        """인터셉트 종료 → 응답 전송 + 상태 복원"""
        self.state = STATE_CMD
        self.current_pkt = None
        self.send_response(hex_data)
        # ★ 규칙 플러시는 별도 스레드에서 (frida 콜백 완료 대기)
        if self.pending_rules:
            def _delayed_flush():
                import time
                time.sleep(0.3)  # frida 콜백이 script.post() 완료할 시간
                self._flush_rules()
            threading.Thread(target=_delayed_flush, daemon=True).start()
        self._show_prompt()

    # ════════════════════════════════════════
    # CMD
    # ════════════════════════════════════════
    def _handle_cmd(self, cmd):
        global show_hex
        parts = cmd.split()
        if not parts:
            return
        action = parts[0].lower()

        if action in ("quit", "exit", "q"):
            raise SystemExit

        elif action == "intercept":
            if len(parts) > 1:
                val = parts[1].lower() in ("on", "true", "1")
                self.script.exports_sync.set_config("interceptOutgoing", val)
                self.script.exports_sync.set_config("logOnly", not val)
                print(f"[*] Intercept: {'ON' if val else 'OFF'}")

        elif action == "monitor":
            self.script.exports_sync.set_config("logOnly", True)
            self.script.exports_sync.set_config("interceptOutgoing", False)
            self.script.exports_sync.set_config("interceptIncoming", False)
            print("[*] Monitor mode")

        elif action == "incoming":
            if len(parts) > 1:
                val = parts[1].lower() in ("on", "true", "1")
                self.script.exports_sync.set_config("interceptIncoming", val)
                print(f"[*] Incoming: {'ON' if val else 'OFF'}")

        elif action == "auto":
            ids = [int(x, 0) for x in parts[1:]]
            self.script.exports_sync.set_config("autoForwardIds", ids)
            print(f"[*] Auto-forward: {[hex(x) for x in ids]}")

        elif action == "hex":
            if len(parts) > 1:
                val = parts[1].lower() in ("on", "true", "1")
            else:
                val = not show_hex
            show_hex = val
            self.script.exports_sync.set_config("showHexDump", val)
            print(f"[*] HexDump: {'ON' if val else 'OFF'}")

        elif action == "str":
            if len(parts) >= 4:
                pid = int(parts[1], 0)
                orig = parts[2]
                repl = " ".join(parts[3:])
                self.script.exports_sync.add_string_rule(pid, orig, repl)
                print(f"[*] S rule: pkt{pid} \"{orig}\" → \"{repl}\"")
            else:
                print("  str <pktId> <원본> <교체>")

        elif action == "enc1":
            if len(parts) == 4:
                pid, idx, val = int(parts[1], 0), int(parts[2]), int(parts[3], 0)
                self.script.exports_sync.add_encode1_rule(pid, idx, val)
                print(f"[*] E1 rule: pkt{pid} #{idx} → {val}")
            else:
                print("  enc1 <pktId> <N> <값>")

        elif action == "enc4":
            if len(parts) == 4:
                pid, idx, val = int(parts[1], 0), int(parts[2]), int(parts[3], 0)
                self.script.exports_sync.add_encode4_rule(pid, idx, val)
                print(f"[*] E4 rule: pkt{pid} #{idx} → {val}")
            else:
                print("  enc4 <pktId> <N> <값>")

        elif action == "enc8":
            if len(parts) == 4:
                pid, idx, val = int(parts[1], 0), int(parts[2]), int(parts[3], 0)
                self.script.exports_sync.add_encode8_rule(pid, idx, val)
                print(f"[*] E8 rule: pkt{pid} #{idx} → {val}")
            else:
                print("  enc8 <pktId> <N> <값>")

        elif action == "field":
            if len(parts) == 4:
                pid = int(parts[1], 0)
                ftype = parts[2]
                names = parts[3].split(",")
                self.script.exports_sync.add_field_def(pid, ftype, names)
                print(f"[*] Field: pkt{pid}.{ftype} = {names}")
            else:
                print("  field <pktId> <type> <n1,n2,...>")

        elif action == "rules":
            result = self.script.exports_sync.list_rules()
            found = False
            for k, v in result.items():
                if v != "{}":
                    print(f"  {k}: {v}")
                    found = True
            if not found:
                print("  (없음)")

        elif action == "clear":
            self.script.exports_sync.clear_rules()
            print("[*] Rules cleared")

        elif action == "config":
            cfg = json.loads(self.script.exports_sync.get_config())
            for k, v in cfg.items():
                print(f"  {k}: {v}")

        elif action == "help":
            print(f"""
{BOLD}── 모드 ──{RESET}
  intercept on/off     인터셉트 모드
  monitor              로그만
  incoming on/off      수신 인터셉트
  auto <id> [id..]     자동 포워드

{BOLD}── 표시 ──{RESET}
  hex [on/off]         hex 덤프 토글

{BOLD}── 규칙 ──{RESET}
  str <pkt> <원본> <교체>     문자열 교체
  enc1 <pkt> <N> <값>        E1 수정
  enc4 <pkt> <N> <값>        E4 수정
  enc8 <pkt> <N> <값>        E8 수정
  field <pkt> <type> <n,n>   필드명 추가
  rules / clear              규칙 확인/초기화

{BOLD}── 인터셉트 시 ──{RESET}
  f = forward    m = modify    d = drop    h = hex

{BOLD}── 수정 모드 ──{RESET}
  S#1=새값  E4#2=999    필드 수정 (규칙 자동 등록)
  4:ff 5:01             offset:hex 수정
  hex <전체hex>         hex 전체 교체
  enter=적용  cancel=취소
""")
        else:
            print(f"[?] {action} (help)")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--spawn", action="store_true")
    args = parser.parse_args()

    device = frida.get_usb_device()
    if args.spawn:
        pid = device.spawn([PACKAGE])
        session = device.attach(pid)
        print(f"[*] Spawned {PACKAGE} (PID: {pid})")
    else:
        session = device.attach(PACKAGE)
        print(f"[*] Attached to {PACKAGE}")

    app = App(session, SCRIPT_PATH)
    app.start()

    if args.spawn:
        device.resume(pid)

    # stdin 스레드 시작
    t = threading.Thread(target=stdin_reader, daemon=True)
    t.start()

    app._show_prompt()

    # ★ 메인 이벤트 루프
    while True:
        try:
            evt_type, evt_data = event_queue.get()
            if not app.process_event(evt_type, evt_data):
                break
        except SystemExit:
            break
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"[!] {e}")
            app._show_prompt()

    session.detach()
    print("\n[*] Done")


if __name__ == "__main__":
    main()