/**
 * HandsPlus Interactive Interceptor v6.0
 * 
 * 변경사항:
 *   - DROP 제거 (forward/modify만)
 *   - 빌드 로그에 수정 여부 표시 (m=true)
 *   - showHexDump 옵션
 */

"use strict";

var CONFIG = {
    interceptOutgoing: true,
    interceptIncoming: false,
    logSocket: true,
    logOnly: false,
    showHexDump: false,
    autoForwardIds: [],
    gameServerIp: "175.207.0.45",
};

// ==================== 유틸리티 ====================
function byteArrayToHex(arr) {
    var hex = "";
    for (var i = 0; i < arr.length; i++) {
        hex += ("0" + (arr[i] & 0xFF).toString(16)).slice(-2);
    }
    return hex;
}

function hexToJByteArray(hex) {
    var bytes = [];
    for (var i = 0; i < hex.length; i += 2) {
        var val = parseInt(hex.substr(i, 2), 16);
        bytes.push(val > 127 ? val - 256 : val);
    }
    return Java.array('byte', bytes);
}

function pktHexdump(bytes, maxLen) {
    maxLen = maxLen || 256;
    var len = Math.min(bytes.length, maxLen);
    var lines = [];
    for (var i = 0; i < len; i += 16) {
        var hex = "";
        var ascii = "";
        for (var j = 0; j < 16; j++) {
            if (i + j < len) {
                var b = bytes[i + j] & 0xFF;
                hex += ("0" + b.toString(16)).slice(-2) + " ";
                ascii += (b >= 0x20 && b <= 0x7E) ? String.fromCharCode(b) : ".";
            } else {
                hex += "   ";
            }
            if (j === 7) hex += " ";
        }
        lines.push(("0000" + i.toString(16)).slice(-4) + "  " + hex + " |" + ascii + "|");
    }
    if (bytes.length > maxLen) lines.push("... (" + bytes.length + " bytes total)");
    return lines.join("\n");
}

function getTimestamp() {
    var d = new Date();
    return d.toTimeString().split(" ")[0] + "." + ("000" + d.getMilliseconds()).slice(-3);
}

// ==================== 패킷 정의 ====================
var PACKET_NAMES = {
    4:    "LOGIN_GAMEID",     5:    "LOGIN_AUTO",
    7:    "CHAR_LIST",        8:    "CHAR_INFO",
    9:    "ITEM_DETAIL",      11:   "SEARCH",
    12:   "SELECT_ACCOUNT",   13:   "CHANGE_OPEN_LEVEL",
    15:   "QUEST_INFO",       17:   "GUILD_MEMBER",
    18:   "FRIEND_LIST",      20:   "NPSN_INFO",
    21:   "PUSH_AGREE_INFO",  22:   "PUSH_AGREE_CHANGE",
    23:   "PUSH_NOTI_HISTORY",24:   "PROBABILITY_ITEM",
    25:   "SAVE_WATCHFACE",   26:   "INSIGN_TICKET",
    27:   "CHAR_QR",          28:   "REDEEM_CHECK",
    29:   "REDEEM_EMP_CODE",  30:   "GET_REDEEM_CODE",
    31:   "COLLECTION_LIST",  32:   "COLLECTION_REGISTER",
    33:   "COLLECTION_CONFIRM",34:  "NGSX_VERIFY",
    35:   "COLLECTION_OPEN",
    3001: "AUCTION_ENTRANCE", 3002: "AUCTION_SEARCH",
    3003: "AUCTION_TREND",    3004: "AUCTION_SEARCH_LIST",
    3005: "AUCTION_ITEM_SELECT",3006:"AUCTION_BUY",
    3007: "AUCTION_BUY_ALL",  3008: "AUCTION_SALE_LIST",
    3009: "AUCTION_COMPLETE_LIST",3010:"AUCTION_WISH_LIST",
    3011: "AUCTION_MARK_REG", 3012: "AUCTION_RE_REG",
    3014: "AUCTION_LIST_MORE",3015: "AUCTION_LIST_SORT",
    3016: "AUCTION_LOGOUT",   3017: "AUCTION_CANCEL",
    3021: "OTP",              3022: "NEXON_SN_SET",
};

function getPacketName(id) {
    return (PACKET_NAMES[id] || "PKT") + "(" + id + ")";
}

// ==================== 파라미터 이름 매핑 ====================
var PACKET_FIELDS = {
    4: {
        encode2: ["version"], encode1: ["padding", "login_type"],
        insertString: ["id_or_token", "pass_or_device", "device_or_adid", "adid_or_version", "os_version"],
        encode8: ["np_sn", "nexon_sn"],
    },
    5: {
        encode2: ["version"], encode1: ["padding", "last_login_type"],
        insertString: ["device_id", "login_token", "adid", "os_version"],
        encode8: ["npsn"],
    },
    7: { encode4: ["account_id"] },
    8: { encode4: ["world_id", "character_id"], insertString: ["character_name"] },
    9: {
        encode4: ["world_id", "character_id", "pos", "item_id", "preset_num?"],
        encode1: ["type"], insertString: ["character_name"],
    },
    11: { insertString: ["keyword"] },
    12: { encode4: ["account_id"] },
    13: { encode4: ["account_id", "open_level"] },
    15: { insertString: ["character_name"], encode4: ["quest_id"], encode1: ["complete"] },
    17: { insertString: ["character_name"] },
    18: { encode4: ["world_id", "character_id"], insertString: ["character_name"] },
    20: { encode4: ["account_id"], encode8: ["np_sn"] },
    21: { encode4: ["account_id"] },
    22: { encode4: ["account_id"], encode1: ["push_type", "agree"] },
    23: { encode4: ["account_id"], encode8: ["last_sn"] },
    24: {
        encode4: ["account_id"], insertString: ["start_date", "end_date"],
        encode1: ["query_type", "cube_filter", "grade_filter"],
    },
    25: {
        encode4: ["account_id", "world_id", "character_id"],
        insertString: ["character_name", "preset_json"],
    },
    26: { insertString: ["public_ip", "np_token"], encode8: ["np_sn", "nexon_sn"] },
    3022: { encode8: ["nexon_sn"] },
};

// ==================== 메인 후킹 ====================
Java.perform(function () {
    console.log("\n[*] ==========================================");
    console.log("[*] HandsPlus Interceptor v6.0");
    console.log("[*] Server: " + CONFIG.gameServerIp);
    console.log("[*] Mode: " + (CONFIG.logOnly ? "MONITOR" : "INTERCEPT"));
    console.log("[*] ==========================================\n");

    var OutPacket = Java.use("com.nexon.handsplus.network.OutPacket");
    var InPacket = Java.use("com.nexon.handsplus.network.InPacket");

    var STRING_MODIFY_RULES = {};
    var ENCODE1_MODIFY_RULES = {};
    var ENCODE4_MODIFY_RULES = {};
    var ENCODE8_MODIFY_RULES = {};

    var currentBuildPacketId = 0;
    var encode1Counter = 0;
    var encode2Counter = 0;
    var encode4Counter = 0;
    var encode8Counter = 0;
    var stringCounter = 0;
    var buildLog = [];

    function getFieldName(pid, type, index) {
        var fields = PACKET_FIELDS[pid];
        if (!fields) return null;
        var arr = fields[type];
        if (!arr || index > arr.length) return null;
        return arr[index - 1] || null;
    }

    // ── OutPacket 빌드 추적 ──
    OutPacket.$init.overload('short').implementation = function (packetId) {
        var pid = packetId & 0xFFFF;
        currentBuildPacketId = pid;
        encode1Counter = 0; encode2Counter = 0;
        encode4Counter = 0; encode8Counter = 0;
        stringCounter = 0; buildLog = [];
        console.log("\n[" + getTimestamp() + "] [BUILD] " + getPacketName(pid));
        return this.$init(packetId);
    };

    OutPacket.Encode1.implementation = function (val) {
        encode1Counter++;
        var pid = currentBuildPacketId;
        var name = getFieldName(pid, "encode1", encode1Counter);
        var label = name ? " [" + name + "]" : "";
        var v = val & 0xFF;
        var modified = false;

        if (ENCODE1_MODIFY_RULES[pid]) {
            var rules = ENCODE1_MODIFY_RULES[pid];
            for (var r = 0; r < rules.length; r++) {
                if (rules[r].index === encode1Counter) {
                    var newVal = rules[r].value;
                    console.log("  ├ E1#" + encode1Counter + label + ": " + v + " → " + newVal + " [MODIFIED]");
                    buildLog.push({ t: "E1", i: encode1Counter, n: name || "", v: newVal, d: v + " → " + newVal, m: true });
                    return this.Encode1(newVal);
                }
            }
        }

        console.log("  ├ E1#" + encode1Counter + label + ": " + v);
        buildLog.push({ t: "E1", i: encode1Counter, n: name || "", v: v, d: "" + v, m: false });
        return this.Encode1(val);
    };

    OutPacket.Encode2.implementation = function (val) {
        encode2Counter++;
        var pid = currentBuildPacketId;
        var name = getFieldName(pid, "encode2", encode2Counter);
        var label = name ? " [" + name + "]" : "";
        var v = val & 0xFFFF;
        console.log("  ├ E2#" + encode2Counter + label + ": " + v);
        buildLog.push({ t: "E2", i: encode2Counter, n: name || "", v: v, d: "" + v, m: false });
        return this.Encode2(val);
    };

    OutPacket.Encode4.implementation = function (val) {
        encode4Counter++;
        var pid = currentBuildPacketId;
        var name = getFieldName(pid, "encode4", encode4Counter);
        var label = name ? " [" + name + "]" : "";

        if (ENCODE4_MODIFY_RULES[pid]) {
            var rules = ENCODE4_MODIFY_RULES[pid];
            for (var r = 0; r < rules.length; r++) {
                if (rules[r].index === encode4Counter) {
                    var newVal = rules[r].value;
                    console.log("  ├ E4#" + encode4Counter + label + ": " + val + " → " + newVal + " [MODIFIED]");
                    buildLog.push({ t: "E4", i: encode4Counter, n: name || "", v: newVal, d: val + " → " + newVal, m: true });
                    return this.Encode4(newVal);
                }
            }
        }

        console.log("  ├ E4#" + encode4Counter + label + ": " + val + " (0x" + (val >>> 0).toString(16) + ")");
        buildLog.push({ t: "E4", i: encode4Counter, n: name || "", v: val, d: val + " (0x" + (val >>> 0).toString(16) + ")", m: false });
        return this.Encode4(val);
    };

    OutPacket.Encode8.implementation = function (val) {
        encode8Counter++;
        var pid = currentBuildPacketId;
        var name = getFieldName(pid, "encode8", encode8Counter);
        var label = name ? " [" + name + "]" : "";

        if (ENCODE8_MODIFY_RULES[pid]) {
            var rules = ENCODE8_MODIFY_RULES[pid];
            for (var r = 0; r < rules.length; r++) {
                if (rules[r].index === encode8Counter) {
                    var newVal = rules[r].value;
                    console.log("  ├ E8#" + encode8Counter + label + ": " + val + " → " + newVal + " [MODIFIED]");
                    buildLog.push({ t: "E8", i: encode8Counter, n: name || "", v: "" + newVal, d: val + " → " + newVal, m: true });
                    return this.Encode8(newVal);
                }
            }
        }

        console.log("  ├ E8#" + encode8Counter + label + ": " + val);
        buildLog.push({ t: "E8", i: encode8Counter, n: name || "", v: "" + val, d: "" + val, m: false });
        return this.Encode8(val);
    };

    OutPacket.InsertString.implementation = function (str) {
        stringCounter++;
        var pid = currentBuildPacketId;
        var name = getFieldName(pid, "insertString", stringCounter);
        var label = name ? " [" + name + "]" : "";
        var s = str || "";

        if (str !== null && STRING_MODIFY_RULES[pid] && STRING_MODIFY_RULES[pid][str] !== undefined) {
            var newStr = STRING_MODIFY_RULES[pid][str];
            console.log("  ├ S#" + stringCounter + label + ": \"" + str + "\" → \"" + newStr + "\" [MODIFIED]");
            buildLog.push({ t: "S", i: stringCounter, n: name || "", v: newStr, d: "\"" + str + "\" → \"" + newStr + "\"", m: true });
            return this.InsertString(newStr);
        }

        console.log("  ├ S#" + stringCounter + label + ": \"" + s + "\"");
        buildLog.push({ t: "S", i: stringCounter, n: name || "", v: s, d: "\"" + s + "\"", m: false });
        return this.InsertString(str);
    };

    // ── OutPacket.Data() → 송신 인터셉트 ──
    OutPacket.Data.implementation = function () {
        var result = this.Data();
        var jsBytes = Java.array('byte', result);
        var packetId = this.packetID.value & 0xFFFF;
        var hexData = byteArrayToHex(jsBytes);
        var ts = getTimestamp();

        console.log("  └─▶ [SEND] " + getPacketName(packetId) + " | " + jsBytes.length + " bytes");
        if (CONFIG.showHexDump) console.log(pktHexdump(jsBytes));

        if (CONFIG.logOnly || !CONFIG.interceptOutgoing ||
            CONFIG.autoForwardIds.indexOf(packetId) !== -1) {
            return result;
        }

        var modifiedHex = null;
        send({
            type: "intercept",
            direction: "outgoing",
            packetId: packetId,
            packetName: getPacketName(packetId),
            size: jsBytes.length,
            hex: hexData,
            timestamp: ts,
            fields: buildLog.slice()
        });

        var op = recv("response", function (msg) {
            modifiedHex = msg.payload;
        });
        op.wait();

        if (modifiedHex !== hexData) {
            console.log("  [✎] MODIFIED & FORWARDED");
            return hexToJByteArray(modifiedHex);
        }

        console.log("  [→] FORWARDED");
        return result;
    };

    // ── InPacket 수신 ──
    InPacket.Decode1.implementation = function () {
        var v = this.Decode1(); var p = this.packetId.value & 0xFFFF;
        console.log("[IN:" + getPacketName(p) + "] D1=" + (v & 0xFF)); return v;
    };
    InPacket.Decode2.implementation = function () {
        var v = this.Decode2(); var p = this.packetId.value & 0xFFFF;
        console.log("[IN:" + getPacketName(p) + "] D2=" + (v & 0xFFFF)); return v;
    };
    InPacket.Decode4.implementation = function () {
        var v = this.Decode4(); var p = this.packetId.value & 0xFFFF;
        console.log("[IN:" + getPacketName(p) + "] D4=" + v); return v;
    };
    InPacket.Decode8.implementation = function () {
        var v = this.Decode8(); var p = this.packetId.value & 0xFFFF;
        console.log("[IN:" + getPacketName(p) + "] D8=" + v); return v;
    };
    InPacket.DecodeString_S.implementation = function () {
        var v = this.DecodeString_S(); var p = this.packetId.value & 0xFFFF;
        if (v && v.length > 0) console.log("[IN:" + getPacketName(p) + "] STR=\"" + v + "\"");
        return v;
    };
    InPacket.DecodeBool.implementation = function () {
        var v = this.DecodeBool(); var p = this.packetId.value & 0xFFFF;
        console.log("[IN:" + getPacketName(p) + "] BOOL=" + v); return v;
    };

    // ── Socket ──
    if (CONFIG.logSocket) {
        var Socket = Java.use("java.net.Socket");
        Socket.connect.overload('java.net.SocketAddress', 'int').implementation = function (a, t) {
            if (a.toString().indexOf(CONFIG.gameServerIp) !== -1)
                console.log("\n[*] ★ Game Server: " + a);
            return this.connect(a, t);
        };
        try {
            var SOS = Java.use("java.net.SocketOutputStream");
            SOS.write.overload('[B', 'int', 'int').implementation = function (b, o, l) {
                if (l > 0) {
                    var tr = Java.use("java.lang.Exception").$new().getStackTrace();
                    for (var i = 0; i < Math.min(tr.length, 10); i++)
                        if (tr[i].getClassName().indexOf("com.nexon.handsplus.network") !== -1) {
                            console.log("[" + getTimestamp() + "] [TCP→] " + l + "B"); break;
                        }
                }
                return this.write(b, o, l);
            };
        } catch (e) {}
        try {
            var SIS = Java.use("java.net.SocketInputStream");
            SIS.read.overload('[B', 'int', 'int').implementation = function (b, o, l) {
                var n = this.read(b, o, l);
                if (n > 0) {
                    var tr = Java.use("java.lang.Exception").$new().getStackTrace();
                    for (var i = 0; i < Math.min(tr.length, 10); i++)
                        if (tr[i].getClassName().indexOf("com.nexon.handsplus.network") !== -1) {
                            console.log("[" + getTimestamp() + "] [TCP←] " + n + "B"); break;
                        }
                }
                return n;
            };
        } catch (e) {}
    }

    // ── RPC ──
    rpc.exports = {
        setConfig: function (k, v) { CONFIG[k] = v; },
        getConfig: function () { return JSON.stringify(CONFIG); },
        setPacketName: function (id, n) { PACKET_NAMES[id] = n; },
        addStringRule: function (pid, orig, repl) {
            if (!STRING_MODIFY_RULES[pid]) STRING_MODIFY_RULES[pid] = {};
            STRING_MODIFY_RULES[pid][orig] = repl;
            console.log("[RULE] S pkt" + pid + " \"" + orig + "\"→\"" + repl + "\"");
        },
        removeStringRule: function (pid, orig) {
            if (STRING_MODIFY_RULES[pid]) delete STRING_MODIFY_RULES[pid][orig];
        },
        addEncode1Rule: function (pid, idx, val) {
            if (!ENCODE1_MODIFY_RULES[pid]) ENCODE1_MODIFY_RULES[pid] = [];
            ENCODE1_MODIFY_RULES[pid].push({ index: idx, value: val });
        },
        addEncode4Rule: function (pid, idx, val) {
            if (!ENCODE4_MODIFY_RULES[pid]) ENCODE4_MODIFY_RULES[pid] = [];
            ENCODE4_MODIFY_RULES[pid].push({ index: idx, value: val });
        },
        addEncode8Rule: function (pid, idx, val) {
            if (!ENCODE8_MODIFY_RULES[pid]) ENCODE8_MODIFY_RULES[pid] = [];
            ENCODE8_MODIFY_RULES[pid].push({ index: idx, value: val });
        },
        addFieldDef: function (pid, ft, names) {
            if (!PACKET_FIELDS[pid]) PACKET_FIELDS[pid] = {};
            PACKET_FIELDS[pid][ft] = names;
        },
        listRules: function () {
            return { string: JSON.stringify(STRING_MODIFY_RULES), encode1: JSON.stringify(ENCODE1_MODIFY_RULES),
                     encode4: JSON.stringify(ENCODE4_MODIFY_RULES), encode8: JSON.stringify(ENCODE8_MODIFY_RULES) };
        },
        clearRules: function () {
            for (var k in STRING_MODIFY_RULES) delete STRING_MODIFY_RULES[k];
            for (var k2 in ENCODE1_MODIFY_RULES) delete ENCODE1_MODIFY_RULES[k2];
            for (var k3 in ENCODE4_MODIFY_RULES) delete ENCODE4_MODIFY_RULES[k3];
            for (var k4 in ENCODE8_MODIFY_RULES) delete ENCODE8_MODIFY_RULES[k4];
        }
    };

    console.log("[*] v6.0 Ready\n");
});